import { execFile } from "node:child_process";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import sharp from "sharp";

const require = createRequire(import.meta.url);
const ffmpegPath = require("ffmpeg-static");
const execFileAsync = promisify(execFile);
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const assets = path.join(root, "app", "assets");
const output = path.join(root, "public", "service-card-journey.webm");

const width = 1280;
const height = 246;
const outputFps = 24;
const sourceFps = 2;
const keyframes = [
  "service-journey-frame-1.webp",
  "service-journey-frame-02.webp",
  "service-journey-frame-03.webp",
  "service-journey-frame-04.webp",
  "service-journey-frame-05.webp",
  "service-journey-frame-06.webp",
  "service-journey-frame-07.webp",
  "service-journey-frame-08.webp",
  "service-journey-frame-09.webp",
  "service-journey-frame-10.webp",
  "service-journey-frame-11.webp",
];

// A duplicate opening and closing frame gives the viewer time to understand the
// start and end of the service journey without creating a visible loop jump.
const timeline = [
  keyframes[0],
  keyframes[0],
  ...keyframes.slice(1),
  keyframes.at(-1),
  keyframes.at(-1),
];

const frameDirectory = await mkdtemp(
  path.join(tmpdir(), "pooshesh-service-video-"),
);

try {
  await Promise.all(
    timeline.map(async (filename, index) => {
      const target = path.join(
        frameDirectory,
        `frame-${String(index).padStart(3, "0")}.png`,
      );

      await sharp(path.join(assets, filename))
        .trim({
          background: { r: 255, g: 255, b: 255 },
          threshold: 12,
        })
        .resize(width, height, {
          fit: "cover",
          position: "center",
        })
        .modulate({ saturation: 1.02 })
        .png({ compressionLevel: 9 })
        .toFile(target);
    }),
  );

  await mkdir(path.dirname(output), { recursive: true });
  await execFileAsync(
    ffmpegPath,
    [
      "-y",
      "-framerate",
      String(sourceFps),
      "-i",
      path.join(frameDirectory, "frame-%03d.png"),
      "-vf",
      [
        [
          `minterpolate=fps=${outputFps}`,
          "mi_mode=mci",
          "mc_mode=aobmc",
          "me_mode=bidir",
          "vsbmc=1",
        ].join(":"),
        "format=yuv420p",
      ].join(","),
      "-an",
      "-c:v",
      "libvpx-vp9",
      "-b:v",
      "0",
      "-crf",
      "38",
      "-deadline",
      "good",
      "-cpu-used",
      "3",
      "-row-mt",
      "1",
      output,
    ],
    {
      maxBuffer: 10 * 1024 * 1024,
      windowsHide: true,
    },
  );

  const metadata = await sharp(
    path.join(frameDirectory, "frame-000.png"),
  ).metadata();

  console.log(
    JSON.stringify({
      output,
      width: metadata.width,
      height: metadata.height,
      fps: outputFps,
      keyframes: keyframes.length,
      durationSeconds: timeline.length / sourceFps,
    }),
  );
} finally {
  await rm(frameDirectory, { recursive: true, force: true });
}
