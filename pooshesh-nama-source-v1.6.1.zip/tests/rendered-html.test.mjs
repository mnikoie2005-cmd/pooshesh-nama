import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const root = new URL("../", import.meta.url);

async function source(path) {
  return readFile(new URL(path, root), "utf8");
}

test("dashboard exposes the release history and featured population card", async () => {
  const [page, styles, versions, publicAdmin] = await Promise.all([
    source("app/page.tsx"),
    source("app/globals.css"),
    source("app/version-data.ts"),
    source("app/public-admin.tsx"),
  ]);

  assert.match(page, /VersionBanner/);
  assert.match(page, /VersionHistoryModal/);
  assert.match(page, /metric-featured-total/);
  assert.match(page, /جمعیت کل تحت پوشش \(بیمه‌شده اصلی و تبعی\)/);
  assert.match(styles, /service-journey-frame-1\.webp/);
  assert.match(styles, /metric-story-video/);
  assert.match(page, /service-card-loop\.webm/);
  assert.match(page, /IntersectionObserver/);
  assert.match(page, /preload="none"/);
  assert.match(styles, /@media \(max-width: 560px\)/);
  assert.match(versions, /version: "1\.6\.1"/);
  assert.match(versions, /ویدیوی سبک کارت جمعیت/);
  assert.match(publicAdmin, /فقط‌خواندنی و بدون نیاز به ورود/);
  assert.match(publicAdmin, /pooshesh-nama-source-v1\.6\.1\.zip/);
});

test("D1 schema and API support protected release management", async () => {
  const [schema, route, store, hosting, admin] = await Promise.all([
    source("db/schema.ts"),
    source("app/api/versions/route.ts"),
    source("db/version-store.ts"),
    source(".openai/hosting.json"),
    source("app/admin/page.tsx"),
  ]);

  assert.match(schema, /sqliteTable\("versions"/);
  assert.match(schema, /sqliteTable\("version_changes"/);
  assert.match(route, /getChatGPTUser/);
  assert.match(route, /export async function POST/);
  assert.match(route, /export async function PUT/);
  assert.match(store, /ensureDefaultVersions/);
  assert.match(store, /DEFAULT_VERSION_HISTORY/);
  assert.match(hosting, /"d1": "DB"/);
  assert.match(admin, /getChatGPTUser/);
  assert.match(admin, /canEdit=\{isVersionAdmin\(user\)\}/);
  assert.match(route, /isVersionAdmin/);
});
