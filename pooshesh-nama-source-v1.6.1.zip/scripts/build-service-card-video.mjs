import { mkdir, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";

const require = createRequire(import.meta.url);
const Whammy = require("whammy");
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const source = path.join(
  root,
  "app",
  "assets",
  "service-journey-frame-1.webp",
);
const output = path.join(root, "public", "service-card-loop.webm");

const width = 1280;
const height = 246;
const fps = 12;
const durationSeconds = 4;
const frameCount = fps * durationSeconds;
const frames = [];

for (let index = 0; index < frameCount; index += 1) {
  const progress = index / frameCount;
  const cycle = Math.PI * 2 * progress;
  const zoom = 1 + 0.06 * ((1 - Math.cos(cycle)) / 2);
  const scaledWidth = Math.ceil(width * zoom);
  const scaledHeight = Math.ceil(height * zoom);
  const horizontalRoom = scaledWidth - width;
  const verticalRoom = scaledHeight - height;
  const left = Math.max(
    0,
    Math.min(
      horizontalRoom,
      Math.round(horizontalRoom * (0.5 + 0.35 * Math.sin(cycle))),
    ),
  );
  const top = Math.max(
    0,
    Math.min(
      verticalRoom,
      Math.round(verticalRoom * (0.5 + 0.18 * Math.sin(cycle + Math.PI / 2))),
    ),
  );
  const brightness = 1 + 0.018 * Math.sin(cycle);

  const frame = await sharp(source)
    .resize(scaledWidth, scaledHeight, {
      fit: "cover",
      position: "center",
    })
    .extract({ left, top, width, height })
    .modulate({ brightness, saturation: 1.025 })
    .webp({
      quality: 48,
      alphaQuality: 60,
      effort: 4,
      smartSubsample: true,
    })
    .toBuffer();

  frames.push(`data:image/webp;base64,${frame.toString("base64")}`);
}

const webm = Whammy.fromImageArray(frames, fps, true);
await mkdir(path.dirname(output), { recursive: true });
await writeFile(output, Buffer.from(webm));

console.log(
  JSON.stringify({
    output,
    width,
    height,
    fps,
    durationSeconds,
    bytes: webm.length,
  }),
);
