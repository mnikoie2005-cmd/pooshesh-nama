import type { Metadata } from "next";
import { headers } from "next/headers";
import "@fontsource-variable/vazirmatn";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host =
    requestHeaders.get("x-forwarded-host") ??
    requestHeaders.get("host") ??
    "localhost:3000";
  const protocol =
    requestHeaders.get("x-forwarded-proto") ??
    (host.includes("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;
  const title = "پوشش‌نما | گزارش جمعیت تحت پوشش";
  const description =
    "تجمیع امن یک یا چند فایل اکسل آمار تأمین اجتماعی و ساخت داشبورد استانی، بدون ارسال فایل به سرور.";
  const imageUrl = `${origin}/og.png`;

  return {
    title,
    description,
    openGraph: {
      title,
      description,
      locale: "fa_IR",
      type: "website",
      images: [{ url: imageUrl, width: 1536, height: 1024, alt: "پوشش‌نما" }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [imageUrl],
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
