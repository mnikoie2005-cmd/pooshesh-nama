export type ReportId =
  | "coverage-province"
  | "coverage-branch"
  | "coverage-treatment-province"
  | "coverage-treatment-branch"
  | "insured-current"
  | "insured-compare"
  | "insured-categories"
  | "workshop-national"
  | "workshop-compare"
  | "pension-current"
  | "pension-national"
  | "trade-treatment"
  | "trade-rate"
  | "trade-rate-new"
  | "insured-without-treatment"
  | "province-profile"
  | "branch-profile";

export type ReportGroup =
  | "coverage"
  | "insured"
  | "workshop"
  | "pension"
  | "trades"
  | "profile";

export type ReportDefinition = {
  id: ReportId;
  title: string;
  description: string;
  group: ReportGroup;
  sourceKeys: string[];
};

export type ReportColumn = {
  key: string;
  label: string;
  format?: "number" | "percent" | "text";
};

export type ReportRecord = Record<string, string | number>;

export type GeneratedReport = {
  definition: ReportDefinition;
  ready: boolean;
  missingSources: string[];
  columns: ReportColumn[];
  rows: ReportRecord[];
  highlights: { label: string; value: number; format?: "number" | "percent" }[];
  note: string;
};

export type SourceRows = Record<string, unknown[][]>;

export const REPORT_GROUP_LABELS: Record<ReportGroup, string> = {
  coverage: "جمعیت تحت پوشش",
  insured: "بیمه‌شدگان",
  workshop: "کارگاه‌ها",
  pension: "مستمری‌بگیران",
  trades: "حرف و مشاغل آزاد",
  profile: "گزارش‌های مدیریتی",
};

export const REPORTS: ReportDefinition[] = [
  {
    id: "coverage-province",
    title: "جمعیت تحت پوشش-استانی",
    description: "ترکیب بیمه‌شدگان و مستمری‌بگیران به تفکیک اداره کل",
    group: "coverage",
    sourceKeys: ["current-insured", "current-pension", "province-list"],
  },
  {
    id: "coverage-branch",
    title: "جمعیت تحت پوشش-شعبه‌ای",
    description: "جمعیت اصلی و تبعی هر شعبه",
    group: "coverage",
    sourceKeys: ["current-insured", "current-pension", "branch-list"],
  },
  {
    id: "coverage-treatment-province",
    title: "جمعیت تحت پوشش درمان-استانی",
    description: "کسر بیمه‌شدگان بدون درمان از پوشش استانی",
    group: "coverage",
    sourceKeys: [
      "current-insured",
      "current-pension",
      "in-person",
      "non-person",
      "commission",
    ],
  },
  {
    id: "coverage-treatment-branch",
    title: "جمعیت تحت پوشش درمان-شعبه‌ای",
    description: "پوشش درمان به تفکیک شعبه",
    group: "coverage",
    sourceKeys: [
      "current-insured",
      "current-pension",
      "in-person",
      "non-person",
      "commission",
    ],
  },
  {
    id: "insured-current",
    title: "بیمه‌شده ماه جاری",
    description: "تجمیع جنسیت و افراد تبعی به تفکیک استان",
    group: "insured",
    sourceKeys: ["current-insured", "province-list"],
  },
  {
    id: "insured-compare",
    title: "مقایسه بیمه‌شده",
    description: "تغییرات ماه جاری نسبت به ماه گذشته",
    group: "insured",
    sourceKeys: ["current-insured", "previous-insured", "province-list"],
  },
  {
    id: "insured-categories",
    title: "جدول بیمه‌شده جدید",
    description: "بیمه‌شدگان به تفکیک نوع بیمه و جنسیت",
    group: "insured",
    sourceKeys: ["current-insured"],
  },
  {
    id: "workshop-national",
    title: "جدول کارگاه",
    description: "کارگاه‌ها بر اساس اندازه و تغییر ماهانه",
    group: "workshop",
    sourceKeys: ["current-workshops", "previous-workshops"],
  },
  {
    id: "workshop-compare",
    title: "مقایسه کارگاه",
    description: "کارگاه‌های فعال ماه جاری و گذشته به تفکیک استان",
    group: "workshop",
    sourceKeys: ["current-workshops", "previous-workshops"],
  },
  {
    id: "pension-current",
    title: "مستمری",
    description: "مستمری‌بگیران اصلی و تبعی به تفکیک استان",
    group: "pension",
    sourceKeys: ["current-pension", "province-list"],
  },
  {
    id: "pension-national",
    title: "جدول مستمری",
    description: "بازنشستگی، ازکارافتادگی، بازماندگان و فوت‌شدگان",
    group: "pension",
    sourceKeys: ["current-pension"],
  },
  {
    id: "trade-treatment",
    title: "تفکیک درمان",
    description: "حرف و مشاغل آزاد با درمان و بدون درمان",
    group: "trades",
    sourceKeys: ["in-person", "non-person"],
  },
  {
    id: "trade-rate",
    title: "تفکیک نرخ",
    description: "تفکیک نرخ‌های ۱۲، ۱۴ و ۱۸ درصد",
    group: "trades",
    sourceKeys: ["in-person", "non-person"],
  },
  {
    id: "trade-rate-new",
    title: "تفکیک نرخ طرح جدید",
    description: "نرخ‌های طرح جدید در داده غیرحضوری",
    group: "trades",
    sourceKeys: ["non-person"],
  },
  {
    id: "insured-without-treatment",
    title: "بیمه‌شدگان بدون درمان",
    description: "حرف بدون درمان به‌علاوه پورسانتاژ",
    group: "trades",
    sourceKeys: ["in-person", "non-person", "commission"],
  },
  {
    id: "province-profile",
    title: "آمار استانی",
    description: "گزیده مدیریتی جمعیت و کارگاه هر اداره کل",
    group: "profile",
    sourceKeys: ["current-insured", "current-pension", "current-workshops"],
  },
  {
    id: "branch-profile",
    title: "آمار شعبه",
    description: "گزیده مدیریتی جمعیت و کارگاه هر شعبه",
    group: "profile",
    sourceKeys: ["current-insured", "current-pension", "current-workshops"],
  },
];

const numberColumns = (entries: [string, string][]): ReportColumn[] =>
  entries.map(([key, label]) => ({ key, label, format: "number" }));

const identityColumns = (branch = false): ReportColumn[] => [
  { key: "provinceCode", label: "کد استان", format: "text" },
  { key: "provinceName", label: "اداره کل", format: "text" },
  ...(branch
    ? [
        { key: "branchCode", label: "کد شعبه", format: "text" } as ReportColumn,
        { key: "branchName", label: "نام شعبه", format: "text" } as ReportColumn,
      ]
    : []),
];

function asNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const parsed = Number(
    String(value ?? "")
      .replace(/[,\u066c\u060c\s]/g, "")
      .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit))),
  );
  return Number.isFinite(parsed) ? parsed : 0;
}

function normalize(value: unknown) {
  return String(value ?? "")
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/\u200c/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function code(value: unknown, width = 2) {
  const digits = String(value ?? "").replace(/\D/g, "");
  return digits ? digits.padStart(width, "0") : "";
}

function percent(delta: number, base: number) {
  return base ? delta / base : 0;
}

type PopulationAggregate = {
  provinceCode: string;
  provinceName: string;
  branchCode: string;
  branchName: string;
  men: number;
  women: number;
  dependents: number;
};

function blankPopulation(
  provinceCode: string,
  provinceName: string,
  branchCode = "",
  branchName = "",
): PopulationAggregate {
  return {
    provinceCode,
    provinceName,
    branchCode,
    branchName,
    men: 0,
    women: 0,
    dependents: 0,
  };
}

function aggregateInsured(rows: unknown[][], byBranch: boolean) {
  const output = new Map<string, PopulationAggregate>();
  const headers = (rows[0] ?? []).map((value) => normalize(value));
  for (const row of rows.slice(1)) {
    const provinceCode = code(row[1]);
    const branchCode = code(row[4], 4);
    if (!provinceCode || (byBranch && !branchCode)) continue;
    const key = byBranch ? branchCode : provinceCode;
    const current =
      output.get(key) ??
      blankPopulation(
        provinceCode,
        normalize(row[2]),
        branchCode,
        normalize(row[3]),
      );
    for (let index = 7; index < headers.length; index += 1) {
      const sourceCode = headers[index].replace(/\D/g, "");
      if (!sourceCode) continue;
      const value = Math.max(0, asNumber(row[index]));
      const lastDigit = sourceCode.at(-1);
      if (lastDigit === "1" || lastDigit === "3") current.men += value;
      if (lastDigit === "2") current.women += value;
      if (lastDigit === "4") current.dependents += value;
    }
    output.set(key, current);
  }
  return output;
}

function aggregatePension(rows: unknown[][], byBranch: boolean) {
  const output = new Map<string, PopulationAggregate>();
  const headers = (rows[0] ?? []).map((value) => normalize(value));
  const personFamilies = new Set([
    "101",
    "201",
    "202",
    "203",
    "391",
    "392",
    "393",
    "394",
  ]);
  for (const row of rows.slice(1)) {
    const provinceCode = code(row[1]);
    const branchCode = code(row[3], 4);
    if (!provinceCode || (byBranch && !branchCode)) continue;
    const key = byBranch ? branchCode : provinceCode;
    const current =
      output.get(key) ??
      blankPopulation(
        provinceCode,
        normalize(row[2]),
        branchCode,
        normalize(row[4]),
      );
    for (let index = 9; index < headers.length; index += 1) {
      const sourceCode = headers[index].replace(/\D/g, "");
      const family = sourceCode.slice(0, -1);
      if (!sourceCode || !personFamilies.has(family)) continue;
      const value = Math.max(0, asNumber(row[index]));
      if (sourceCode.endsWith("1") || sourceCode.endsWith("3")) {
        current.men += value;
      } else if (sourceCode.endsWith("2")) {
        current.women += value;
      } else if (sourceCode.endsWith("4")) {
        current.dependents += value;
      }
    }
    output.set(key, current);
  }
  return output;
}

type TradeAggregate = {
  provinceCode: string;
  provinceName: string;
  branchCode: string;
  branchName: string;
  values: Record<string, number>;
};

function aggregateTradeSources(sources: SourceRows) {
  const output = new Map<string, TradeAggregate>();
  for (const sourceKey of ["in-person", "non-person"]) {
    const rows = sources[sourceKey] ?? [];
    const headers = (rows[0] ?? []).map((value) =>
      normalize(value).replace(/'/g, ""),
    );
    for (const row of rows.slice(1)) {
      const branchCode = code(row[5], 4);
      if (!branchCode) continue;
      const current =
        output.get(branchCode) ?? {
          provinceCode: code(row[3]),
          provinceName: normalize(row[4]),
          branchCode,
          branchName: normalize(row[6]),
          values: {},
        };
      for (let index = 7; index < headers.length; index += 1) {
        const sourceCode = headers[index].replace(/\D/g, "");
        if (!sourceCode) continue;
        current.values[sourceCode] =
          (current.values[sourceCode] ?? 0) + Math.max(0, asNumber(row[index]));
      }
      output.set(branchCode, current);
    }
  }
  return output;
}

function tradeBucket(
  values: Record<string, number>,
  groups: string[],
): { men: number; women: number; dependents: number; total: number } {
  let men = 0;
  let women = 0;
  let dependents = 0;
  for (const group of groups) {
    men += values[`${group}1`] ?? 0;
    women += (values[`${group}2`] ?? 0) + (values[`${group}3`] ?? 0);
    dependents += values[`${group}4`] ?? 0;
  }
  return { men, women, dependents, total: men + women };
}

function aggregateCommission(rows: unknown[][]) {
  const output = new Map<
    string,
    { men: number; women: number; dependents: number }
  >();
  for (const row of rows.slice(1)) {
    const branchCode = code(row[3], 4);
    if (!branchCode) continue;
    output.set(branchCode, {
      men: Math.max(0, asNumber(row[5])),
      women: Math.max(0, asNumber(row[6])),
      dependents: Math.max(0, asNumber(row[7])),
    });
  }
  return output;
}

function withoutTreatmentByBranch(sources: SourceRows) {
  const trades = aggregateTradeSources(sources);
  const commissions = aggregateCommission(sources.commission ?? []);
  const output = new Map<string, PopulationAggregate>();
  for (const [branchCode, trade] of trades) {
    const tradeWithout = tradeBucket(trade.values, ["12", "22", "32", "42", "52", "62"]);
    const commission = commissions.get(branchCode) ?? {
      men: 0,
      women: 0,
      dependents: 0,
    };
    output.set(branchCode, {
      provinceCode: trade.provinceCode,
      provinceName: trade.provinceName,
      branchCode,
      branchName: trade.branchName,
      men: tradeWithout.men + commission.men,
      women: tradeWithout.women + commission.women,
      dependents: tradeWithout.dependents + commission.dependents,
    });
  }
  return output;
}

function sumHighlights(
  rows: ReportRecord[],
  keys: [string, string][],
): GeneratedReport["highlights"] {
  return keys.map(([key, label]) => ({
    label,
    value: rows.reduce((total, row) => total + asNumber(row[key]), 0),
  }));
}

function populationRows(sources: SourceRows, byBranch: boolean, treatment: boolean) {
  const insured = aggregateInsured(sources["current-insured"] ?? [], byBranch);
  const pension = aggregatePension(sources["current-pension"] ?? [], byBranch);
  const without = treatment ? withoutTreatmentByBranch(sources) : new Map();
  const withoutByScope = new Map<string, PopulationAggregate>();
  if (treatment) {
    for (const item of without.values()) {
      const scopeKey = byBranch ? item.branchCode : item.provinceCode;
      const current =
        withoutByScope.get(scopeKey) ??
        blankPopulation(
          item.provinceCode,
          item.provinceName,
          item.branchCode,
          item.branchName,
        );
      current.men += item.men;
      current.women += item.women;
      current.dependents += item.dependents;
      withoutByScope.set(scopeKey, current);
    }
  }
  const keys = new Set([...insured.keys(), ...pension.keys()]);
  return [...keys].map<ReportRecord>((key) => {
    const insuredItem = insured.get(key) ?? blankPopulation("", "");
    const pensionItem = pension.get(key) ?? blankPopulation("", "");
    const excluded = withoutByScope.get(key) ?? blankPopulation("", "");
    const insuredMen = Math.max(0, insuredItem.men - excluded.men);
    const insuredWomen = Math.max(0, insuredItem.women - excluded.women);
    const insuredDependents = Math.max(
      0,
      insuredItem.dependents - excluded.dependents,
    );
    const insuredTotal = insuredMen + insuredWomen;
    const pensionTotal = pensionItem.men + pensionItem.women;
    const primaryMen = insuredMen + pensionItem.men;
    const primaryWomen = insuredWomen + pensionItem.women;
    const primaryTotal = insuredTotal + pensionTotal;
    const dependents = insuredDependents + pensionItem.dependents;
    return {
      provinceCode: insuredItem.provinceCode || pensionItem.provinceCode,
      provinceName: insuredItem.provinceName || pensionItem.provinceName,
      ...(byBranch
        ? {
            branchCode: insuredItem.branchCode || pensionItem.branchCode,
            branchName: insuredItem.branchName || pensionItem.branchName,
          }
        : {}),
      insuredMen,
      insuredWomen,
      insuredTotal,
      insuredDependents,
      pensionMen: pensionItem.men,
      pensionWomen: pensionItem.women,
      pensionTotal,
      pensionDependents: pensionItem.dependents,
      primaryMen,
      primaryWomen,
      primaryTotal,
      dependents,
      grandTotal: primaryTotal + dependents,
    };
  });
}

const populationColumns = (branch: boolean): ReportColumn[] => [
  ...identityColumns(branch),
  ...numberColumns([
    ["insuredMen", "بیمه‌شده مرد"],
    ["insuredWomen", "بیمه‌شده زن"],
    ["insuredTotal", "جمع بیمه‌شده اصلی"],
    ["insuredDependents", "بیمه‌شده تبعی"],
    ["pensionMen", "مستمری مرد"],
    ["pensionWomen", "مستمری زن"],
    ["pensionTotal", "جمع مستمری اصلی"],
    ["pensionDependents", "مستمری تبعی"],
    ["primaryMen", "جمعیت اصلی مرد"],
    ["primaryWomen", "جمعیت اصلی زن"],
    ["primaryTotal", "جمعیت اصلی"],
    ["dependents", "جمعیت تبعی"],
    ["grandTotal", "جمع کل"],
  ]),
];

function insuredProvinceRows(rows: unknown[][]) {
  return [...aggregateInsured(rows, false).values()].map<ReportRecord>((item) => ({
    provinceCode: item.provinceCode,
    provinceName: item.provinceName,
    men: item.men,
    women: item.women,
    primary: item.men + item.women,
    dependents: item.dependents,
    total: item.men + item.women + item.dependents,
  }));
}

function insuredComparisonRows(sources: SourceRows) {
  const current = aggregateInsured(sources["current-insured"] ?? [], false);
  const previous = aggregateInsured(sources["previous-insured"] ?? [], false);
  const keys = new Set([...current.keys(), ...previous.keys()]);
  return [...keys].map<ReportRecord>((key) => {
    const currentItem = current.get(key) ?? blankPopulation(key, "");
    const previousItem = previous.get(key) ?? blankPopulation(key, "");
    const currentValue = currentItem.men + currentItem.women;
    const previousValue = previousItem.men + previousItem.women;
    const delta = currentValue - previousValue;
    return {
      provinceCode: key,
      provinceName: currentItem.provinceName || previousItem.provinceName,
      current: currentValue,
      previous: previousValue,
      delta,
      change: percent(delta, previousValue),
    };
  });
}

const insuredCategoryGroups: [string, string[]][] = [
  ["اجباری", ["1"]],
  ["حرف و مشاغل آزاد", ["13", "14"]],
  ["اختیاری", ["2", "3"]],
  ["رانندگان", ["4"]],
  ["قالیبافان", ["5"]],
  ["کارگران ساختمانی", ["6"]],
  ["کارفرمایان صنفی", ["7"]],
  ["زنبورداران", ["8"]],
  ["باربران", ["9"]],
  ["خادمین", ["10"]],
  ["توافقی", ["11"]],
  ["بیکاری", ["12"]],
];

function insuredCategoryRows(rows: unknown[][]) {
  const headers = (rows[0] ?? []).map((value) =>
    normalize(value).replace(/\D/g, ""),
  );
  const totals = new Map<
    string,
    { men: number; women: number; dependents: number }
  >();
  for (const [label] of insuredCategoryGroups) {
    totals.set(label, { men: 0, women: 0, dependents: 0 });
  }
  for (const row of rows.slice(1)) {
    for (let index = 7; index < headers.length; index += 1) {
      const sourceCode = headers[index];
      const family = sourceCode.slice(0, -1);
      const group = insuredCategoryGroups.find(([, families]) =>
        families.includes(family),
      );
      if (!group) continue;
      const value = Math.max(0, asNumber(row[index]));
      const bucket = totals.get(group[0])!;
      const lastDigit = sourceCode.at(-1);
      if (lastDigit === "1" || lastDigit === "3") bucket.men += value;
      if (lastDigit === "2") bucket.women += value;
      if (lastDigit === "4") bucket.dependents += value;
    }
  }
  return [...totals].map<ReportRecord>(([category, item]) => ({
    category,
    men: item.men,
    women: item.women,
    primary: item.men + item.women,
    dependents: item.dependents,
    total: item.men + item.women + item.dependents,
  }));
}

const workshopBuckets: [number, string][] = [
  [6, "پیمان‌های صفرنفره"],
  [7, "کارگاه‌های ۱ نفره"],
  [8, "کارگاه‌های ۲ نفره"],
  [9, "کارگاه‌های ۳ نفره"],
  [10, "کارگاه‌های ۴ نفره"],
  [11, "کارگاه‌های ۵ نفره"],
  [12, "کارگاه‌های ۶ تا ۱۰ نفره"],
  [13, "کارگاه‌های ۱۱ تا ۵۰ نفره"],
  [14, "کارگاه‌های بالای ۵۰ نفر"],
  [15, "جمع کارگاه فعال"],
];

function workshopNationalRows(sources: SourceRows) {
  const current = sources["current-workshops"] ?? [];
  const previous = sources["previous-workshops"] ?? [];
  return workshopBuckets.map<ReportRecord>(([index, label]) => {
    const currentValue = current
      .slice(1)
      .reduce((sum, row) => sum + Math.max(0, asNumber(row[index])), 0);
    const previousValue = previous
      .slice(1)
      .reduce((sum, row) => sum + Math.max(0, asNumber(row[index])), 0);
    const delta = currentValue - previousValue;
    return {
      category: label,
      current: currentValue,
      previous: previousValue,
      delta,
      change: percent(delta, previousValue),
    };
  });
}

function aggregateWorkshops(rows: unknown[][], byBranch: boolean) {
  const output = new Map<
    string,
    {
      provinceCode: string;
      provinceName: string;
      branchCode: string;
      branchName: string;
      active: number;
    }
  >();
  for (const row of rows.slice(1)) {
    const provinceCode = code(row[2]);
    const branchCode = code(row[4], 4);
    const key = byBranch ? branchCode : provinceCode;
    if (!key) continue;
    const current =
      output.get(key) ?? {
        provinceCode,
        provinceName: normalize(row[3]),
        branchCode,
        branchName: normalize(row[5]),
        active: 0,
      };
    current.active += Math.max(0, asNumber(row[15]));
    output.set(key, current);
  }
  return output;
}

function workshopComparisonRows(sources: SourceRows) {
  const current = aggregateWorkshops(sources["current-workshops"] ?? [], false);
  const previous = aggregateWorkshops(sources["previous-workshops"] ?? [], false);
  const keys = new Set([...current.keys(), ...previous.keys()]);
  return [...keys].map<ReportRecord>((key) => {
    const currentItem = current.get(key);
    const previousItem = previous.get(key);
    const currentValue = currentItem?.active ?? 0;
    const previousValue = previousItem?.active ?? 0;
    const delta = currentValue - previousValue;
    return {
      provinceCode: key,
      provinceName:
        currentItem?.provinceName ?? previousItem?.provinceName ?? "",
      current: currentValue,
      previous: previousValue,
      delta,
      change: percent(delta, previousValue),
    };
  });
}

function pensionProvinceRows(rows: unknown[][]) {
  return [...aggregatePension(rows, false).values()].map<ReportRecord>((item) => ({
    provinceCode: item.provinceCode,
    provinceName: item.provinceName,
    men: item.men,
    women: item.women,
    primary: item.men + item.women,
    dependents: item.dependents,
    total: item.men + item.women + item.dependents,
  }));
}

const pensionCategoryGroups: [string, string[]][] = [
  ["بازنشستگان", ["101"]],
  ["ازکارافتادگان", ["201", "202", "203"]],
  ["بازماندگان", ["391", "392", "393", "394"]],
  ["فوت‌شدگان", ["301", "302", "303", "304"]],
];

function pensionCategoryRows(rows: unknown[][]) {
  const headers = (rows[0] ?? []).map((value) =>
    normalize(value).replace(/\D/g, ""),
  );
  return pensionCategoryGroups.map<ReportRecord>(([category, families]) => {
    let men = 0;
    let women = 0;
    let dependents = 0;
    for (const row of rows.slice(1)) {
      for (let index = 9; index < headers.length; index += 1) {
        const sourceCode = headers[index];
        if (!families.includes(sourceCode.slice(0, -1))) continue;
        const value = Math.max(0, asNumber(row[index]));
        if (sourceCode.endsWith("1") || sourceCode.endsWith("3")) men += value;
        if (sourceCode.endsWith("2")) women += value;
        if (sourceCode.endsWith("4")) dependents += value;
      }
    }
    return {
      category,
      men,
      women,
      primary: men + women,
      dependents,
      total: men + women + dependents,
    };
  });
}

function tradeRows(sources: SourceRows, mode: "treatment" | "rate" | "rate-new" | "without") {
  const trades = aggregateTradeSources(sources);
  const commissions = aggregateCommission(sources.commission ?? []);
  return [...trades.values()].map<ReportRecord>((trade) => {
    const base: ReportRecord = {
      provinceCode: trade.provinceCode,
      provinceName: trade.provinceName,
      branchCode: trade.branchCode,
      branchName: trade.branchName,
    };
    if (mode === "treatment") {
      const covered = tradeBucket(trade.values, ["11", "21", "31", "41", "51", "61"]);
      const uncovered = tradeBucket(trade.values, ["12", "22", "32", "42", "52", "62"]);
      return {
        ...base,
        coveredMen: covered.men,
        coveredWomen: covered.women,
        coveredPrimary: covered.total,
        coveredDependents: covered.dependents,
        uncoveredMen: uncovered.men,
        uncoveredWomen: uncovered.women,
        uncoveredPrimary: uncovered.total,
        uncoveredDependents: uncovered.dependents,
        total: covered.total + covered.dependents + uncovered.total + uncovered.dependents,
      };
    }
    if (mode === "without") {
      const uncovered = tradeBucket(trade.values, ["12", "22", "32", "42", "52", "62"]);
      const commission = commissions.get(trade.branchCode) ?? {
        men: 0,
        women: 0,
        dependents: 0,
      };
      const men = uncovered.men + commission.men;
      const women = uncovered.women + commission.women;
      const dependents = uncovered.dependents + commission.dependents;
      return {
        ...base,
        tradeMen: uncovered.men,
        tradeWomen: uncovered.women,
        commissionMen: commission.men,
        commissionWomen: commission.women,
        men,
        women,
        primary: men + women,
        dependents,
        total: men + women + dependents,
      };
    }
    const groups =
      mode === "rate-new"
        ? [
            ["rate12", ["41", "42"]],
            ["rate14", ["51", "52"]],
            ["rate18", ["61", "62"]],
          ]
        : [
            ["rate12", ["11", "12"]],
            ["rate14", ["21", "22"]],
            ["rate18", ["31", "32"]],
          ];
    let grandTotal = 0;
    for (const [key, families] of groups) {
      const bucket = tradeBucket(trade.values, families as string[]);
      base[`${key}Men`] = bucket.men;
      base[`${key}Women`] = bucket.women;
      base[`${key}Primary`] = bucket.total;
      base[`${key}Dependents`] = bucket.dependents;
      grandTotal += bucket.total + bucket.dependents;
    }
    base.total = grandTotal;
    return base;
  });
}

function profileRows(sources: SourceRows, byBranch: boolean) {
  const population = populationRows(sources, byBranch, false);
  const workshops = aggregateWorkshops(
    sources["current-workshops"] ?? [],
    byBranch,
  );
  return population.map<ReportRecord>((row) => {
    const key = String(byBranch ? row.branchCode : row.provinceCode);
    return {
      provinceCode: row.provinceCode,
      provinceName: row.provinceName,
      ...(byBranch
        ? { branchCode: row.branchCode, branchName: row.branchName }
        : {}),
      insured: row.insuredTotal,
      pension: row.pensionTotal,
      covered: row.grandTotal,
      activeWorkshops: workshops.get(key)?.active ?? 0,
    };
  });
}

function columnsForReport(id: ReportId): ReportColumn[] {
  if (id === "coverage-branch") return populationColumns(true);
  if (id === "coverage-treatment-province") return populationColumns(false);
  if (id === "coverage-treatment-branch") return populationColumns(true);
  if (id === "insured-current" || id === "pension-current") {
    return [
      ...identityColumns(false),
      ...numberColumns([
        ["men", "مرد"],
        ["women", "زن"],
        ["primary", "جمع اصلی"],
        ["dependents", "تبعی"],
        ["total", "جمع کل"],
      ]),
    ];
  }
  if (id === "insured-compare" || id === "workshop-compare") {
    return [
      ...identityColumns(false),
      ...numberColumns([
        ["current", "ماه جاری"],
        ["previous", "ماه گذشته"],
        ["delta", "تغییر"],
      ]),
      { key: "change", label: "درصد تغییر", format: "percent" },
    ];
  }
  if (id === "insured-categories" || id === "pension-national") {
    return [
      { key: "category", label: "شرح", format: "text" },
      ...numberColumns([
        ["men", "مرد"],
        ["women", "زن"],
        ["primary", "جمع اصلی"],
        ["dependents", "تبعی"],
        ["total", "جمع کل"],
      ]),
    ];
  }
  if (id === "workshop-national") {
    return [
      { key: "category", label: "شرح", format: "text" },
      ...numberColumns([
        ["current", "ماه جاری"],
        ["previous", "ماه گذشته"],
        ["delta", "تغییر"],
      ]),
      { key: "change", label: "درصد تغییر", format: "percent" },
    ];
  }
  if (id === "trade-treatment") {
    return [
      ...identityColumns(true),
      ...numberColumns([
        ["coveredMen", "با درمان مرد"],
        ["coveredWomen", "با درمان زن"],
        ["coveredPrimary", "جمع اصلی با درمان"],
        ["coveredDependents", "تبعی با درمان"],
        ["uncoveredMen", "بدون درمان مرد"],
        ["uncoveredWomen", "بدون درمان زن"],
        ["uncoveredPrimary", "جمع اصلی بدون درمان"],
        ["uncoveredDependents", "تبعی بدون درمان"],
        ["total", "جمع کل"],
      ]),
    ];
  }
  if (id === "trade-rate" || id === "trade-rate-new") {
    return [
      ...identityColumns(true),
      ...numberColumns([
        ["rate12Men", "۱۲٪ مرد"],
        ["rate12Women", "۱۲٪ زن"],
        ["rate12Primary", "۱۲٪ اصلی"],
        ["rate12Dependents", "۱۲٪ تبعی"],
        ["rate14Men", "۱۴٪ مرد"],
        ["rate14Women", "۱۴٪ زن"],
        ["rate14Primary", "۱۴٪ اصلی"],
        ["rate14Dependents", "۱۴٪ تبعی"],
        ["rate18Men", "۱۸٪ مرد"],
        ["rate18Women", "۱۸٪ زن"],
        ["rate18Primary", "۱۸٪ اصلی"],
        ["rate18Dependents", "۱۸٪ تبعی"],
        ["total", "جمع کل"],
      ]),
    ];
  }
  if (id === "insured-without-treatment") {
    return [
      ...identityColumns(true),
      ...numberColumns([
        ["tradeMen", "حرف مرد"],
        ["tradeWomen", "حرف زن"],
        ["commissionMen", "پورسانتاژ مرد"],
        ["commissionWomen", "پورسانتاژ زن"],
        ["men", "جمع مرد"],
        ["women", "جمع زن"],
        ["primary", "جمع اصلی"],
        ["dependents", "تبعی"],
        ["total", "جمع کل"],
      ]),
    ];
  }
  if (id === "province-profile" || id === "branch-profile") {
    return [
      ...identityColumns(id === "branch-profile"),
      ...numberColumns([
        ["insured", "بیمه‌شده اصلی"],
        ["pension", "مستمری‌بگیر اصلی"],
        ["covered", "جمعیت تحت پوشش"],
        ["activeWorkshops", "کارگاه فعال"],
      ]),
    ];
  }
  return [];
}

function rowsForReport(id: ReportId, sources: SourceRows): ReportRecord[] {
  switch (id) {
    case "coverage-branch":
      return populationRows(sources, true, false);
    case "coverage-treatment-province":
      return populationRows(sources, false, true);
    case "coverage-treatment-branch":
      return populationRows(sources, true, true);
    case "insured-current":
      return insuredProvinceRows(sources["current-insured"] ?? []);
    case "insured-compare":
      return insuredComparisonRows(sources);
    case "insured-categories":
      return insuredCategoryRows(sources["current-insured"] ?? []);
    case "workshop-national":
      return workshopNationalRows(sources);
    case "workshop-compare":
      return workshopComparisonRows(sources);
    case "pension-current":
      return pensionProvinceRows(sources["current-pension"] ?? []);
    case "pension-national":
      return pensionCategoryRows(sources["current-pension"] ?? []);
    case "trade-treatment":
      return tradeRows(sources, "treatment");
    case "trade-rate":
      return tradeRows(sources, "rate");
    case "trade-rate-new":
      return tradeRows(sources, "rate-new");
    case "insured-without-treatment":
      return tradeRows(sources, "without");
    case "province-profile":
      return profileRows(sources, false);
    case "branch-profile":
      return profileRows(sources, true);
    default:
      return [];
  }
}

export function buildGeneratedReport(
  id: ReportId,
  sources: SourceRows,
): GeneratedReport {
  const definition = REPORTS.find((report) => report.id === id)!;
  const missingSources = definition.sourceKeys.filter(
    (sourceKey) => !(sources[sourceKey]?.length > 1),
  );
  const ready = missingSources.length === 0;
  const rows = ready ? rowsForReport(id, sources) : [];
  const columns = columnsForReport(id);
  const totalKey =
    columns.find((column) => column.key === "grandTotal")?.key ??
    columns.find((column) => column.key === "total")?.key ??
    columns.find((column) => column.key === "current")?.key ??
    columns.find((column) => column.key === "covered")?.key ??
    "";
  let highlights = totalKey
    ? sumHighlights(rows, [[totalKey, "جمع گزارش"]])
    : [];
  if (id === "workshop-national") {
    const totalRow = rows.find((row) =>
      normalize(row.category).includes("جمع کارگاه فعال"),
    );
    highlights = [
      { label: "کارگاه فعال ماه جاری", value: asNumber(totalRow?.current) },
      { label: "کارگاه فعال ماه گذشته", value: asNumber(totalRow?.previous) },
    ];
  }
  if (id === "pension-national") {
    highlights = [
      {
        label: "جمع اصلی بر اساس نفر",
        value: rows
          .filter((row) => normalize(row.category) !== "فوت شدگان")
          .reduce((total, row) => total + asNumber(row.primary), 0),
      },
    ];
  }
  highlights.push({ label: "تعداد ردیف", value: rows.length });
  return {
    definition,
    ready,
    missingSources,
    columns,
    rows,
    highlights,
    note: ready
      ? "این گزارش در مرورگر و مستقیماً از شیت‌های مرجع محاسبه شده است."
      : "پس از تکمیل منابع مشخص‌شده، جدول به‌صورت خودکار ساخته می‌شود.",
  };
}
