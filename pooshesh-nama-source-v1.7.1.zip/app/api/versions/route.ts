import { getChatGPTUser, isVersionAdmin } from "../../chatgpt-auth";
import {
  createVersion,
  ensureDefaultVersions,
  listVersions,
  updateVersion,
} from "../../../db/version-store";
import {
  VERSION_TYPES,
  VersionChangeItem,
  VersionEntry,
  VersionType,
} from "../../version-data";

export const dynamic = "force-dynamic";

type VersionPayload = Omit<VersionEntry, "id" | "createdBy"> & {
  id?: number;
};

function errorMessage(error: unknown) {
  const message = error instanceof Error ? error.message : "خطای ناشناخته";
  if (message.includes("no such table")) {
    return "جدول نسخه‌ها هنوز در پایگاه داده ایجاد نشده است. انتشار را دوباره انجام دهید.";
  }
  if (message.includes("UNIQUE constraint failed")) {
    return "این شماره نسخه قبلاً ثبت شده است.";
  }
  return message;
}

function validatePayload(payload: Partial<VersionPayload>) {
  const version = payload.version?.trim() ?? "";
  const title = payload.title?.trim() ?? "";
  const summary = payload.summary?.trim() ?? "";
  const releasedAt = payload.releasedAt?.trim() ?? "";
  const versionType = payload.versionType as VersionType;
  const rawChanges = Array.isArray(payload.changes) ? payload.changes : [];
  const changes: VersionChangeItem[] = rawChanges
    .map((change) => ({
      changeType: change.changeType as VersionType,
      description: change.description?.trim() ?? "",
    }))
    .filter((change) => change.description);

  if (!version || !title || !releasedAt) {
    throw new Error("شماره نسخه، عنوان و تاریخ انتشار الزامی است.");
  }
  if (!VERSION_TYPES.includes(versionType)) {
    throw new Error("نوع نسخه معتبر نیست.");
  }
  if (!changes.length) {
    throw new Error("حداقل یک ردیف تغییر وارد کنید.");
  }
  if (changes.some((change) => !VERSION_TYPES.includes(change.changeType))) {
    throw new Error("نوع یکی از تغییرات معتبر نیست.");
  }

  return {
    version,
    versionType,
    title,
    summary,
    releasedAt,
    isPublished: payload.isPublished ?? true,
    changes,
  };
}

export async function GET() {
  try {
    await ensureDefaultVersions();
    return Response.json({ versions: await listVersions() });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!isVersionAdmin(user)) {
    return Response.json({ error: "دسترسی ویرایش فقط برای مدیر فعال است." }, { status: 403 });
  }
  try {
    const input = validatePayload(
      (await request.json()) as Partial<VersionPayload>,
    );
    const version = await createVersion(input, user!.email);
    return Response.json({ version }, { status: 201 });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 400 });
  }
}

export async function PUT(request: Request) {
  const user = await getChatGPTUser();
  if (!isVersionAdmin(user)) {
    return Response.json({ error: "دسترسی ویرایش فقط برای مدیر فعال است." }, { status: 403 });
  }
  try {
    const payload = (await request.json()) as Partial<VersionPayload>;
    if (!Number.isInteger(payload.id) || Number(payload.id) <= 0) {
      throw new Error("شناسه نسخه معتبر نیست.");
    }
    const input = validatePayload(payload);
    const version = await updateVersion(Number(payload.id), input, user!.email);
    if (!version) {
      return Response.json({ error: "نسخه پیدا نشد." }, { status: 404 });
    }
    return Response.json({ version });
  } catch (error) {
    return Response.json({ error: errorMessage(error) }, { status: 400 });
  }
}
