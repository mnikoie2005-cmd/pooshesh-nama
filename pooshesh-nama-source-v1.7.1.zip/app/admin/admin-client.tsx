"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  VERSION_TYPES,
  VersionChangeItem,
  VersionEntry,
  VersionType,
} from "../version-data";

type Props = {
  canEdit: boolean;
  displayName: string | null;
  email: string | null;
  signInPath: string;
  signOutPath: string;
};

type VersionForm = Omit<VersionEntry, "id" | "createdBy"> & {
  id?: number;
};

const EMPTY_CHANGE: VersionChangeItem = {
  changeType: "قابلیت جدید",
  description: "",
};

function emptyForm(): VersionForm {
  return {
    version: "",
    versionType: "قابلیت جدید",
    title: "",
    summary: "",
    releasedAt: new Date().toISOString().slice(0, 10),
    isPublished: true,
    changes: [{ ...EMPTY_CHANGE }],
  };
}

function formatDate(value: string) {
  try {
    return new Intl.DateTimeFormat("fa-IR", { dateStyle: "medium" }).format(
      new Date(`${value}T12:00:00`),
    );
  } catch {
    return value;
  }
}

export default function AdminClient({
  canEdit,
  displayName,
  email,
  signInPath,
  signOutPath,
}: Props) {
  const [versions, setVersions] = useState<VersionEntry[]>([]);
  const [form, setForm] = useState<VersionForm>(() => emptyForm());
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const editing = useMemo(
    () => versions.find((item) => item.id === form.id),
    [form.id, versions],
  );

  async function loadVersions() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/versions", { cache: "no-store" });
      const result = (await response.json()) as {
        versions?: VersionEntry[];
        error?: string;
      };
      if (!response.ok) throw new Error(result.error || "خطا در دریافت نسخه‌ها");
      setVersions(result.versions ?? []);
    } catch (loadError) {
      setError(
        loadError instanceof Error ? loadError.message : "خطا در دریافت نسخه‌ها",
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    let active = true;
    void fetch("/api/versions", { cache: "no-store" })
      .then(async (response) => {
        const result = (await response.json()) as {
          versions?: VersionEntry[];
          error?: string;
        };
        if (!response.ok) {
          throw new Error(result.error || "خطا در دریافت نسخه‌ها");
        }
        if (active) setVersions(result.versions ?? []);
      })
      .catch((loadError: unknown) => {
        if (active) {
          setError(
            loadError instanceof Error
              ? loadError.message
              : "خطا در دریافت نسخه‌ها",
          );
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  function editVersion(version: VersionEntry) {
    setForm({
      id: version.id,
      version: version.version,
      versionType: version.versionType,
      title: version.title,
      summary: version.summary,
      releasedAt: version.releasedAt,
      isPublished: version.isPublished ?? true,
      changes: version.changes.map((change) => ({ ...change })),
    });
    setMessage("");
    setError("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function resetForm() {
    setForm(emptyForm());
    setMessage("");
    setError("");
  }

  function updateChange(
    index: number,
    field: "changeType" | "description",
    value: string,
  ) {
    setForm((current) => ({
      ...current,
      changes: current.changes.map((change, changeIndex) =>
        changeIndex === index ? { ...change, [field]: value } : change,
      ),
    }));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const response = await fetch("/api/versions", {
        method: form.id ? "PUT" : "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(form),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "ذخیره انجام نشد.");
      setMessage(form.id ? "نسخه با موفقیت به‌روزرسانی شد." : "نسخه جدید ثبت شد.");
      setForm(emptyForm());
      await loadVersions();
    } catch (saveError) {
      setError(
        saveError instanceof Error ? saveError.message : "ذخیره انجام نشد.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="admin-shell">
      <header className="admin-topbar">
        <div>
          <span className="section-kicker">مدیریت خصوصی</span>
          <h1>گزارش تغییرات نسخه‌ها</h1>
          {canEdit ? (
            <p>
              مدیر واردشده: <strong>{displayName}</strong>
              <small>{email}</small>
            </p>
          ) : (
            <p>
              <strong>نمایش عمومی و فقط‌خواندنی</strong>
              <span>همه می‌توانند تاریخچه را ببینند؛ ویرایش فقط برای مدیر است.</span>
            </p>
          )}
        </div>
        <nav>
          <Link className="secondary-button" href="/">
            بازگشت به برنامه
          </Link>
          {canEdit || email ? (
            <a className="ghost-button" href={signOutPath}>
              خروج از حساب
            </a>
          ) : (
            <a className="primary-button" href={signInPath}>
              ورود مدیر برای ویرایش
            </a>
          )}
        </nav>
      </header>

      <section className={`admin-layout ${canEdit ? "" : "is-read-only"}`}>
        {canEdit ? (
          <form className="version-form" onSubmit={submit}>
          <div className="version-form-heading">
            <div>
              <span className="section-kicker">
                {editing ? "ویرایش نسخه" : "نسخه تازه"}
              </span>
              <h2>{editing ? editing.title : "ثبت یک انتشار جدید"}</h2>
            </div>
            {editing && (
              <button className="ghost-button" type="button" onClick={resetForm}>
                انصراف از ویرایش
              </button>
            )}
          </div>

          <div className="admin-field-grid">
            <label>
              شماره نسخه
              <input
                required
                dir="ltr"
                placeholder="1.6.0"
                value={form.version}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    version: event.target.value,
                  }))
                }
              />
            </label>
            <label>
              نوع نسخه
              <select
                value={form.versionType}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    versionType: event.target.value as VersionType,
                  }))
                }
              >
                {VERSION_TYPES.map((type) => (
                  <option value={type} key={type}>
                    {type}
                  </option>
                ))}
              </select>
            </label>
            <label>
              تاریخ انتشار
              <input
                required
                type="date"
                value={form.releasedAt}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    releasedAt: event.target.value,
                  }))
                }
              />
            </label>
            <label className="admin-wide-field">
              عنوان نسخه
              <input
                required
                value={form.title}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    title: event.target.value,
                  }))
                }
              />
            </label>
            <label className="admin-wide-field">
              خلاصه
              <textarea
                rows={3}
                value={form.summary}
                onChange={(event) =>
                  setForm((current) => ({
                    ...current,
                    summary: event.target.value,
                  }))
                }
              />
            </label>
          </div>

          <div className="change-editor">
            <div>
              <h3>ردیف‌های تغییر</h3>
              <button
                type="button"
                className="secondary-button"
                onClick={() =>
                  setForm((current) => ({
                    ...current,
                    changes: [...current.changes, { ...EMPTY_CHANGE }],
                  }))
                }
              >
                افزودن تغییر
              </button>
            </div>
            {form.changes.map((change, index) => (
              <div className="change-edit-row" key={`${index}-${change.id ?? "new"}`}>
                <select
                  aria-label={`نوع تغییر ${index + 1}`}
                  value={change.changeType}
                  onChange={(event) =>
                    updateChange(index, "changeType", event.target.value)
                  }
                >
                  {VERSION_TYPES.map((type) => (
                    <option value={type} key={type}>
                      {type}
                    </option>
                  ))}
                </select>
                <textarea
                  required
                  rows={2}
                  aria-label={`شرح تغییر ${index + 1}`}
                  placeholder="شرح دقیق تغییر"
                  value={change.description}
                  onChange={(event) =>
                    updateChange(index, "description", event.target.value)
                  }
                />
                <button
                  type="button"
                  aria-label={`حذف تغییر ${index + 1}`}
                  disabled={form.changes.length === 1}
                  onClick={() =>
                    setForm((current) => ({
                      ...current,
                      changes: current.changes.filter(
                        (_, changeIndex) => changeIndex !== index,
                      ),
                    }))
                  }
                >
                  حذف
                </button>
              </div>
            ))}
          </div>

          {error && <p className="admin-alert admin-alert-error">{error}</p>}
          {message && <p className="admin-alert admin-alert-ok">{message}</p>}
          <button className="primary-button admin-save" type="submit" disabled={busy}>
            {busy ? "در حال ذخیره…" : form.id ? "ذخیره ویرایش" : "ثبت نسخه"}
          </button>
          </form>
        ) : (
          <article className="admin-read-only-note">
            <span aria-hidden="true">👁</span>
            <div>
              <strong>این صفحه برای مشاهده عمومی باز است</strong>
              <p>
                نسخه‌ها و ردیف‌های تغییر از پایگاه داده خوانده می‌شوند. فرم ثبت
                و ویرایش فقط پس از ورود حساب مدیر نمایش داده می‌شود.
              </p>
            </div>
          </article>
        )}

        <aside className="admin-version-list">
          <div>
            <span className="section-kicker">نسخه‌های ثبت‌شده</span>
            <h2>{loading ? "در حال دریافت…" : `${versions.length} نسخه`}</h2>
          </div>
          {versions.map((version) => (
            <article key={version.id ?? version.version}>
              <div>
                <span className="version-type-chip">{version.versionType}</span>
                <strong dir="ltr">v{version.version}</strong>
              </div>
              <h3>{version.title}</h3>
              <p>{version.summary}</p>
              <small>
                {formatDate(version.releasedAt)} · {version.changes.length} تغییر
              </small>
              {canEdit && (
                <button
                  type="button"
                  className="secondary-button"
                  onClick={() => editVersion(version)}
                >
                  ویرایش این نسخه
                </button>
              )}
            </article>
          ))}
        </aside>
      </section>
    </main>
  );
}
