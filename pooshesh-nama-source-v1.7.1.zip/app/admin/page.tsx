import {
  chatGPTSignInPath,
  chatGPTSignOutPath,
  getChatGPTUser,
  isVersionAdmin,
} from "../chatgpt-auth";
import AdminClient from "./admin-client";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getChatGPTUser();

  return (
    <AdminClient
      canEdit={isVersionAdmin(user)}
      displayName={user?.displayName ?? null}
      email={user?.email ?? null}
      signInPath={chatGPTSignInPath("/admin")}
      signOutPath={chatGPTSignOutPath("/")}
    />
  );
}
