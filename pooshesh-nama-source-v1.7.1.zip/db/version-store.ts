import { asc, desc, eq, inArray, sql } from "drizzle-orm";
import {
  DEFAULT_VERSION_HISTORY,
  VersionEntry,
  VersionType,
} from "../app/version-data";
import { getDb } from "./index";
import { versionChanges, versions } from "./schema";

type VersionInput = Omit<VersionEntry, "id" | "createdBy">;

export async function ensureDefaultVersions() {
  const db = getDb();
  const existing = await db
    .select({ version: versions.version })
    .from(versions);
  const knownVersions = new Set(existing.map((item) => item.version));

  for (const entry of [...DEFAULT_VERSION_HISTORY].reverse()) {
    if (knownVersions.has(entry.version)) continue;
    const [created] = await db
      .insert(versions)
      .values({
        version: entry.version,
        versionType: entry.versionType,
        title: entry.title,
        summary: entry.summary,
        releasedAt: entry.releasedAt,
        createdBy: "release",
        isPublished: true,
      })
      .returning({ id: versions.id });
    if (created && entry.changes.length) {
      await db.insert(versionChanges).values(
        entry.changes.map((change, position) => ({
          versionId: created.id,
          changeType: change.changeType,
          description: change.description,
          position,
        })),
      );
    }
  }
}

export async function listVersions(): Promise<VersionEntry[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(versions)
    .where(eq(versions.isPublished, true))
    .orderBy(desc(versions.releasedAt), desc(versions.id));

  if (!rows.length) return [];
  const ids = rows.map((row) => row.id);
  const changes = await db
    .select()
    .from(versionChanges)
    .where(inArray(versionChanges.versionId, ids))
    .orderBy(asc(versionChanges.position), asc(versionChanges.id));

  return rows.map((row) => ({
    ...row,
    versionType: row.versionType as VersionType,
    changes: changes
      .filter((change) => change.versionId === row.id)
      .map((change) => ({
        id: change.id,
        changeType: change.changeType as VersionType,
        description: change.description,
      })),
  }));
}

export async function createVersion(input: VersionInput, userEmail: string) {
  const db = getDb();
  const [created] = await db
    .insert(versions)
    .values({
      version: input.version,
      versionType: input.versionType,
      title: input.title,
      summary: input.summary,
      releasedAt: input.releasedAt,
      createdBy: userEmail,
      isPublished: input.isPublished ?? true,
    })
    .returning();

  if (input.changes.length) {
    await db.insert(versionChanges).values(
      input.changes.map((change, position) => ({
        versionId: created.id,
        changeType: change.changeType,
        description: change.description,
        position,
      })),
    );
  }
  return created;
}

export async function updateVersion(
  id: number,
  input: VersionInput,
  userEmail: string,
) {
  const db = getDb();
  const [updated] = await db
    .update(versions)
    .set({
      version: input.version,
      versionType: input.versionType,
      title: input.title,
      summary: input.summary,
      releasedAt: input.releasedAt,
      createdBy: userEmail,
      isPublished: input.isPublished ?? true,
      updatedAt: sql`CURRENT_TIMESTAMP`,
    })
    .where(eq(versions.id, id))
    .returning();

  if (!updated) return null;
  await db.delete(versionChanges).where(eq(versionChanges.versionId, id));
  if (input.changes.length) {
    await db.insert(versionChanges).values(
      input.changes.map((change, position) => ({
        versionId: id,
        changeType: change.changeType,
        description: change.description,
        position,
      })),
    );
  }
  return updated;
}
