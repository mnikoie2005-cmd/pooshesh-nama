import { sql } from "drizzle-orm";
import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const versions = sqliteTable("versions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  version: text("version").notNull().unique(),
  versionType: text("version_type").notNull(),
  title: text("title").notNull(),
  summary: text("summary").notNull().default(""),
  releasedAt: text("released_at").notNull(),
  createdBy: text("created_by").notNull().default("system"),
  isPublished: integer("is_published", { mode: "boolean" })
    .notNull()
    .default(true),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const versionChanges = sqliteTable("version_changes", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  versionId: integer("version_id")
    .notNull()
    .references(() => versions.id, { onDelete: "cascade" }),
  changeType: text("change_type").notNull(),
  description: text("description").notNull(),
  position: integer("position").notNull().default(0),
});
