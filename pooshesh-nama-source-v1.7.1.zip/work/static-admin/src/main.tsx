import React from "react";
import { createRoot } from "react-dom/client";
import "@fontsource-variable/vazirmatn";
import "../../../app/globals.css";
import PublicAdmin from "../../../app/public-admin";

const root = document.getElementById("root");

if (!root) {
  throw new Error("ریشهٔ صفحه مدیریت پیدا نشد.");
}

createRoot(root).render(
  <React.StrictMode>
    <PublicAdmin />
  </React.StrictMode>,
);
