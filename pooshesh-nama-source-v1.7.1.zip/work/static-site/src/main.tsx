import React from "react";
import { createRoot } from "react-dom/client";
import "@fontsource-variable/vazirmatn";
import "../../../app/globals.css";
import App from "../../../app/page";

const root = document.getElementById("root");

if (!root) {
  throw new Error("ریشهٔ برنامه پیدا نشد.");
}

createRoot(root).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
