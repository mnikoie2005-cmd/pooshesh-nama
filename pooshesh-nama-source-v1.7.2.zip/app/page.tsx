"use client";

import {
  ChangeEvent,
  DragEvent,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { PersonStanding, UserRoundCheck } from "lucide-react";
import * as XLSX from "xlsx";
import {
  buildGeneratedReport,
  GeneratedReport,
  REPORT_GROUP_LABELS,
  REPORTS,
  ReportId,
  SourceRows,
} from "./report-engine";
import {
  DEFAULT_VERSION_HISTORY,
  VersionEntry,
  VersionType,
} from "./version-data";

type ProvinceRow = {
  code: string;
  name: string;
  insuredMen: number;
  insuredWomen: number;
  insuredTotal: number;
  insuredDependents: number;
  pensionMen: number;
  pensionWomen: number;
  pensionTotal: number;
  pensionDependents: number;
  primaryMen: number;
  primaryWomen: number;
  primaryTotal: number;
  dependents: number;
  grandTotal: number;
};

type Summary = {
  insuredMen: number;
  insuredWomen: number;
  insuredTotal: number;
  insuredDependents: number;
  pensionMen: number;
  pensionWomen: number;
  pensionTotal: number;
  pensionDependents: number;
  primaryMen: number;
  primaryWomen: number;
  primaryTotal: number;
  dependents: number;
  grandTotal: number;
};

type CheckItem = {
  label: string;
  detail: string;
  status: "ok" | "warn";
};

type ParseResult = {
  rows: ProvinceRow[];
  sourceMode: "source" | "report";
  checks: CheckItem[];
  period: string;
};

type SourceRequirement = {
  key: string;
  sheetName: string;
  title: string;
  description: string;
  group: "core" | "additional" | "legacy";
  requiredForCurrentReport: boolean;
};

type LoadedWorkbook = {
  id: string;
  fileName: string;
  size: number;
  workbook: XLSX.WorkBook;
  recognizedSheets: string[];
};

type SourceMatch = {
  fileId: string;
  fileName: string;
  workbook: XLSX.WorkBook;
  sheetName: string;
};

const SOURCE_REQUIREMENTS: SourceRequirement[] = [
  {
    key: "current-insured",
    sheetName: "ماه جاری",
    title: "بیمه‌شدگان ماه جاری",
    description: "داده خام شعب برای محاسبه بیمه‌شدگان استانی",
    group: "core",
    requiredForCurrentReport: true,
  },
  {
    key: "current-pension",
    sheetName: "مستمری ماه جاری",
    title: "مستمری ماه جاری",
    description: "داده خام مستمری‌بگیران به تفکیک شعبه",
    group: "core",
    requiredForCurrentReport: true,
  },
  {
    key: "province-list",
    sheetName: "لیست استان",
    title: "مرجع استان‌ها",
    description: "کد و نام اداره‌های کل",
    group: "core",
    requiredForCurrentReport: true,
  },
  {
    key: "previous-insured",
    sheetName: "ماه گذشته",
    title: "بیمه‌شدگان ماه گذشته",
    description: "ورودی گزارش‌های مقایسه ماهانه",
    group: "additional",
    requiredForCurrentReport: false,
  },
  {
    key: "current-workshops",
    sheetName: "کارگاه-شعب -ماه جاری",
    title: "کارگاه شعب ماه جاری",
    description: "ورودی گزارش کارگاه‌های فعال",
    group: "additional",
    requiredForCurrentReport: false,
  },
  {
    key: "previous-workshops",
    sheetName: "کارگاه -شعب-ماه گذشته",
    title: "کارگاه شعب ماه گذشته",
    description: "ورودی مقایسه کارگاه‌ها",
    group: "additional",
    requiredForCurrentReport: false,
  },
  {
    key: "branch-list",
    sheetName: "لیست شعب",
    title: "مرجع شعب",
    description: "کد، اداره کل و نام شعبه",
    group: "additional",
    requiredForCurrentReport: false,
  },
  {
    key: "in-person",
    sheetName: "حضوری",
    title: "حرف و مشاغل حضوری",
    description: "ورودی تفکیک نرخ و درمان",
    group: "additional",
    requiredForCurrentReport: false,
  },
  {
    key: "non-person",
    sheetName: "غیر حضوری",
    title: "حرف و مشاغل غیرحضوری",
    description: "ورودی تفکیک نرخ و درمان",
    group: "additional",
    requiredForCurrentReport: false,
  },
  {
    key: "commission",
    sheetName: "پورسانتاژ",
    title: "پورسانتاژ",
    description: "ورودی محاسبه پوشش درمان",
    group: "additional",
    requiredForCurrentReport: false,
  },
  {
    key: "legacy-total",
    sheetName: "مجموع",
    title: "مجموع قدیمی",
    description: "مرجع موقت دانشجویان و زنان خانه‌دار",
    group: "legacy",
    requiredForCurrentReport: false,
  },
];

const CURRENT_REPORT_REQUIREMENTS = SOURCE_REQUIREMENTS.filter(
  (source) => source.requiredForCurrentReport,
);

const numberFormat = new Intl.NumberFormat("fa-IR");
const percentFormat = new Intl.NumberFormat("fa-IR", {
  maximumFractionDigits: 1,
  minimumFractionDigits: 1,
});

type AppPage = "home" | "settings" | "dashboard" | ReportId;

const reportIds = new Set<ReportId>(REPORTS.map((report) => report.id));

function isReportPage(page: AppPage): page is ReportId {
  return reportIds.has(page as ReportId);
}

const EMPTY_SUMMARY: Summary = {
  insuredMen: 0,
  insuredWomen: 0,
  insuredTotal: 0,
  insuredDependents: 0,
  pensionMen: 0,
  pensionWomen: 0,
  pensionTotal: 0,
  pensionDependents: 0,
  primaryMen: 0,
  primaryWomen: 0,
  primaryTotal: 0,
  dependents: 0,
  grandTotal: 0,
};

const faDigits = "۰۱۲۳۴۵۶۷۸۹";
const jalaliMonthNames = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

function toFaDigits(value: string | number) {
  return String(value).replace(/\d/g, (digit) => faDigits[Number(digit)]);
}

function formatDashboardPeriod(value: string) {
  const latinValue = String(value).replace(/[۰-۹]/g, (digit) =>
    String(faDigits.indexOf(digit)),
  );
  const match = latinValue.match(/(\d{4})\s*[/.-]\s*(\d{1,2})/);
  if (!match) return value;
  const month = Number(match[2]);
  if (month < 1 || month > 12) return value;
  return `${jalaliMonthNames[month - 1]} ${toFaDigits(match[1])}`;
}

function formatReleaseDate(value: string) {
  try {
    return new Intl.DateTimeFormat("fa-IR", { dateStyle: "medium" }).format(
      new Date(`${value}T12:00:00`),
    );
  } catch {
    return toFaDigits(value);
  }
}

function normalizeText(value: unknown) {
  return String(value ?? "")
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/\u200c/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeSheetName(value: string) {
  return normalizeText(value).replace(/\s/g, "");
}

function findSheetName(workbook: XLSX.WorkBook, expected: string) {
  const target = normalizeSheetName(expected);
  return workbook.SheetNames.find(
    (sheetName) => normalizeSheetName(sheetName) === target,
  );
}

function asNumber(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const cleaned = String(value ?? "")
    .replace(/[,\u066c\u060c\s]/g, "")
    .replace(/[۰-۹]/g, (digit) => String(faDigits.indexOf(digit)));
  const parsed = Number(cleaned);
  return Number.isFinite(parsed) ? parsed : 0;
}

function provinceCode(value: unknown) {
  const raw = String(value ?? "").replace(/\D/g, "");
  return raw ? raw.padStart(2, "0") : "";
}

function sheetRows(sheet: XLSX.WorkSheet) {
  return XLSX.utils.sheet_to_json<unknown[]>(sheet, {
    header: 1,
    raw: true,
    defval: null,
  });
}

function sourcePeriod(
  rows: unknown[][] | undefined,
  yearIndex: number,
  monthIndex: number,
) {
  const row = rows?.slice(1).find(
    (item) => item[yearIndex] != null && item[monthIndex] != null,
  );
  if (!row) return "";
  const year = normalizeText(row[yearIndex]);
  const month = normalizeText(row[monthIndex]).padStart(2, "0");
  return year && month ? `${toFaDigits(year)}/${toFaDigits(month)}` : "";
}

function detectReportPeriod(reportId: ReportId, sources: SourceRows) {
  const current =
    sourcePeriod(sources["current-insured"], 5, 6) ||
    sourcePeriod(sources["current-pension"], 5, 6) ||
    sourcePeriod(sources["current-workshops"], 0, 1) ||
    sourcePeriod(sources["in-person"], 1, 2) ||
    sourcePeriod(sources["non-person"], 1, 2);
  if (reportId === "insured-compare" || reportId === "workshop-compare") {
    const previous =
      sourcePeriod(sources["previous-insured"], 5, 6) ||
      sourcePeriod(sources["previous-workshops"], 0, 1);
    if (current && previous) return `${current} در مقایسه با ${previous}`;
  }
  return current || "پس از ورود فایل مشخص می‌شود";
}

function col(letter: string) {
  return XLSX.utils.decode_col(letter);
}

const INSURED_MEN_COLUMNS = [
  "BH",
  "BJ",
  "BD",
  "BF",
  "AV",
  "AX",
  "AZ",
  "BB",
  "AN",
  "AP",
  "AR",
  "AT",
  "AJ",
  "AL",
  "AF",
  "AB",
  "AD",
  "P",
  "R",
  "L",
  "N",
  "X",
  "Z",
  "T",
  "V",
  "H",
];
const INSURED_WOMEN_COLUMNS = [
  "BI",
  "BE",
  "AW",
  "BA",
  "AO",
  "AS",
  "AK",
  "AG",
  "AC",
  "Q",
  "M",
  "Y",
  "U",
  "I",
];
const INSURED_DEPENDENT_COLUMNS = [
  "BK",
  "BG",
  "AY",
  "BC",
  "AQ",
  "AU",
  "AM",
  "AI",
  "AE",
  "S",
  "O",
  "AA",
  "W",
  "K",
];
const PENSION_MEN_COLUMNS = [
  "V",
  "R",
  "N",
  "X",
  "T",
  "P",
  "AP",
  "AT",
  "AX",
  "BB",
  "AR",
  "AV",
  "AZ",
  "BD",
  "J",
  "L",
];
const PENSION_WOMEN_COLUMNS = [
  "W",
  "S",
  "O",
  "AQ",
  "AU",
  "AY",
  "BC",
  "K",
];
const PENSION_DEPENDENT_COLUMNS = [
  "Y",
  "U",
  "Q",
  "BE",
  "BA",
  "AW",
  "AS",
  "M",
];

function sumColumns(row: unknown[], columns: string[]) {
  return columns.reduce((total, letter) => total + asNumber(row[col(letter)]), 0);
}

function sourceMatches(files: LoadedWorkbook[]) {
  const matches = new Map<string, SourceMatch[]>();
  for (const requirement of SOURCE_REQUIREMENTS) {
    const requirementMatches: SourceMatch[] = [];
    for (const file of files) {
      const sheetName = findSheetName(file.workbook, requirement.sheetName);
      if (sheetName) {
        requirementMatches.push({
          fileId: file.id,
          fileName: file.fileName,
          workbook: file.workbook,
          sheetName,
        });
      }
    }
    matches.set(requirement.key, requirementMatches);
  }
  return matches;
}

function activeSourceMap(files: LoadedWorkbook[]) {
  const matches = sourceMatches(files);
  const active = new Map<string, SourceMatch>();
  for (const requirement of SOURCE_REQUIREMENTS) {
    const candidates = matches.get(requirement.key) ?? [];
    const selected = candidates.at(-1);
    if (selected) active.set(requirement.key, selected);
  }
  return active;
}

function parseRawSourceFiles(files: LoadedWorkbook[]): ParseResult | null {
  const active = activeSourceMap(files);
  if (
    !CURRENT_REPORT_REQUIREMENTS.every((requirement) =>
      active.has(requirement.key),
    )
  ) {
    return null;
  }

  const insuredSource = active.get("current-insured")!;
  const pensionSource = active.get("current-pension")!;
  const provinceSource = active.get("province-list")!;
  const insuredRows = sheetRows(
    insuredSource.workbook.Sheets[insuredSource.sheetName],
  );
  const pensionRows = sheetRows(
    pensionSource.workbook.Sheets[pensionSource.sheetName],
  );
  const provinceRows = sheetRows(
    provinceSource.workbook.Sheets[provinceSource.sheetName],
  );

  type Aggregate = {
    name: string;
    men: number;
    women: number;
    dependents: number;
  };

  const insuredByProvince = new Map<string, Aggregate>();
  for (const row of insuredRows.slice(1)) {
    const code = provinceCode(row[1]);
    if (!code || code === "00") continue;
    const current = insuredByProvince.get(code) ?? {
      name: normalizeText(row[2]),
      men: 0,
      women: 0,
      dependents: 0,
    };
    current.men +=
      sumColumns(row, INSURED_MEN_COLUMNS) +
      Math.max(0, asNumber(row[col("J")])) +
      Math.max(0, asNumber(row[col("AH")]));
    current.women += sumColumns(row, INSURED_WOMEN_COLUMNS);
    current.dependents += sumColumns(row, INSURED_DEPENDENT_COLUMNS);
    insuredByProvince.set(code, current);
  }

  const pensionByProvince = new Map<string, Aggregate>();
  for (const row of pensionRows.slice(1)) {
    const code = provinceCode(row[1]);
    if (!code || code === "00") continue;
    const current = pensionByProvince.get(code) ?? {
      name: normalizeText(row[2]),
      men: 0,
      women: 0,
      dependents: 0,
    };
    current.men += sumColumns(row, PENSION_MEN_COLUMNS);
    current.women += sumColumns(row, PENSION_WOMEN_COLUMNS);
    current.dependents += sumColumns(row, PENSION_DEPENDENT_COLUMNS);
    pensionByProvince.set(code, current);
  }

  let missingProvinceData = 0;
  const rows: ProvinceRow[] = [];
  for (const row of provinceRows.slice(1)) {
    const code = provinceCode(row[0]);
    const name = normalizeText(row[1]);
    if (!code || !name || code === "00") continue;
    const insured = insuredByProvince.get(code);
    const pension = pensionByProvince.get(code);
    if (!insured || !pension) missingProvinceData += 1;
    const insuredMen = insured?.men ?? 0;
    const insuredWomen = insured?.women ?? 0;
    const insuredDependents = insured?.dependents ?? 0;
    const pensionMen = pension?.men ?? 0;
    const pensionWomen = pension?.women ?? 0;
    const pensionDependents = pension?.dependents ?? 0;
    const insuredTotal = insuredMen + insuredWomen;
    const pensionTotal = pensionMen + pensionWomen;
    rows.push({
      code,
      name,
      insuredMen,
      insuredWomen,
      insuredTotal,
      insuredDependents,
      pensionMen,
      pensionWomen,
      pensionTotal,
      pensionDependents,
      primaryMen: insuredMen + pensionMen,
      primaryWomen: insuredWomen + pensionWomen,
      primaryTotal: insuredTotal + pensionTotal,
      dependents: insuredDependents + pensionDependents,
      grandTotal:
        insuredTotal +
        pensionTotal +
        insuredDependents +
        pensionDependents,
    });
  }

  if (!rows.length) {
    throw new Error("در شیت «لیست استان» ردیف مرجع قابل‌خواندن پیدا نشد.");
  }

  const firstCurrentRow = insuredRows.slice(1).find((row) => row[1] != null);
  const year = normalizeText(firstCurrentRow?.[5]);
  const month = normalizeText(firstCurrentRow?.[6]).padStart(2, "0");
  const uniqueFileCount = new Set(
    CURRENT_REPORT_REQUIREMENTS.map(
      (requirement) => active.get(requirement.key)!.fileId,
    ),
  ).size;

  return {
    rows,
    sourceMode: "source",
    period: year && month ? `${toFaDigits(year)}/${toFaDigits(month)}` : "دورهٔ ورودی",
    checks: [
      {
        label: "منابع اصلی کامل است",
        detail: "ماه جاری، مستمری ماه جاری و لیست استان شناسایی شد.",
        status: "ok",
      },
      {
        label: "چیدمان فایل‌ها",
        detail:
          uniqueFileCount === 1
            ? "هر سه منبع از یک فایل اکسل چندشیتی خوانده شد."
            : `منابع از ${toFaDigits(uniqueFileCount)} فایل اکسل مستقل تجمیع شد.`,
        status: "ok",
      },
      {
        label: "تطبیق اداره‌های کل",
        detail: missingProvinceData
          ? `${toFaDigits(missingProvinceData)} اداره کل دادهٔ کامل ندارد.`
          : `${toFaDigits(rows.length)} اداره کل با کد مرجع تطبیق داده شد.`,
        status: missingProvinceData ? "warn" : "ok",
      },
      {
        label: "محاسبه مستقل",
        detail:
          "اعداد مستقیماً از داده‌های خام محاسبه شد؛ فرمول یا لینک خارجی وارد گزارش نشد.",
        status: "ok",
      },
    ],
  };
}

function summarize(rows: ProvinceRow[]): Summary {
  return rows.reduce<Summary>(
    (total, row) => ({
      insuredMen: total.insuredMen + row.insuredMen,
      insuredWomen: total.insuredWomen + row.insuredWomen,
      insuredTotal: total.insuredTotal + row.insuredTotal,
      insuredDependents:
        total.insuredDependents + row.insuredDependents,
      pensionMen: total.pensionMen + row.pensionMen,
      pensionWomen: total.pensionWomen + row.pensionWomen,
      pensionTotal: total.pensionTotal + row.pensionTotal,
      pensionDependents:
        total.pensionDependents + row.pensionDependents,
      primaryMen: total.primaryMen + row.primaryMen,
      primaryWomen: total.primaryWomen + row.primaryWomen,
      primaryTotal: total.primaryTotal + row.primaryTotal,
      dependents: total.dependents + row.dependents,
      grandTotal: total.grandTotal + row.grandTotal,
    }),
    {
      insuredMen: 0,
      insuredWomen: 0,
      insuredTotal: 0,
      insuredDependents: 0,
      pensionMen: 0,
      pensionWomen: 0,
      pensionTotal: 0,
      pensionDependents: 0,
      primaryMen: 0,
      primaryWomen: 0,
      primaryTotal: 0,
      dependents: 0,
      grandTotal: 0,
    },
  );
}

function parseSourceWorkbook(workbook: XLSX.WorkBook): ParseResult | null {
  const insuredName = findSheetName(
    workbook,
    "بیمه شده استان ماه جاری",
  );
  const pensionName = findSheetName(workbook, "مستمری استان");
  if (!insuredName || !pensionName) return null;

  const insuredRows = sheetRows(workbook.Sheets[insuredName]);
  const pensionRows = sheetRows(workbook.Sheets[pensionName]);
  const pensionByCode = new Map<string, unknown[]>();

  for (const row of pensionRows) {
    const code = provinceCode(row[0]);
    const name = normalizeText(row[1]);
    if (code && name && code !== "00") pensionByCode.set(code, row);
  }

  const rows: ProvinceRow[] = [];
  let invalidRows = 0;
  let balanceWarnings = 0;

  for (const row of insuredRows) {
    const code = provinceCode(row[0]);
    const name = normalizeText(row[1]);
    if (!code || !name || code === "00" || normalizeText(row[0]) === "جمع") {
      continue;
    }

    const pension = pensionByCode.get(code);
    if (!pension) {
      invalidRows += 1;
      continue;
    }

    const insuredMen = asNumber(row[col("BO")]);
    const insuredWomen = asNumber(row[col("BP")]);
    const insuredTotal = asNumber(row[col("BQ")]);
    const insuredDependents = asNumber(row[col("BR")]);
    const pensionMen = asNumber(pension[col("C")]);
    const pensionWomen = asNumber(pension[col("D")]);
    const pensionTotal = asNumber(pension[col("E")]);
    const pensionDependents = asNumber(pension[col("F")]);

    if (
      insuredMen + insuredWomen !== insuredTotal ||
      pensionMen + pensionWomen !== pensionTotal
    ) {
      balanceWarnings += 1;
    }

    rows.push({
      code,
      name,
      insuredMen,
      insuredWomen,
      insuredTotal,
      insuredDependents,
      pensionMen,
      pensionWomen,
      pensionTotal,
      pensionDependents,
      primaryMen: insuredMen + pensionMen,
      primaryWomen: insuredWomen + pensionWomen,
      primaryTotal: insuredTotal + pensionTotal,
      dependents: insuredDependents + pensionDependents,
      grandTotal:
        insuredTotal +
        pensionTotal +
        insuredDependents +
        pensionDependents,
    });
  }

  if (!rows.length) {
    throw new Error("دادهٔ استانی قابل‌خواندن در دو شیت منبع پیدا نشد.");
  }

  const currentSheet = findSheetName(workbook, "ماه جاری");
  let period = "دورهٔ فایل ورودی";
  if (currentSheet) {
    const currentRows = sheetRows(workbook.Sheets[currentSheet]);
    const year = normalizeText(currentRows[1]?.[5]);
    const month = normalizeText(currentRows[1]?.[6]);
    if (year && month) period = `${toFaDigits(year)}/${toFaDigits(month)}`;
  }

  return {
    rows,
    sourceMode: "source",
    period,
    checks: [
      {
        label: "شیت‌های منبع",
        detail: `هر دو شیت لازم پیدا شد: «${insuredName}» و «${pensionName}».`,
        status: "ok",
      },
      {
        label: "تطبیق استان‌ها",
        detail: `${toFaDigits(rows.length)} استان/اداره کل با کد مشترک تطبیق داده شد.`,
        status: invalidRows ? "warn" : "ok",
      },
      {
        label: "کنترل جمع مرد و زن",
        detail: balanceWarnings
          ? `${toFaDigits(balanceWarnings)} ردیف نیازمند بازبینی است.`
          : "جمع اصلی هر ردیف با مرد و زن تطبیق دارد.",
        status: balanceWarnings ? "warn" : "ok",
      },
      {
        label: "فرمول‌های اکسل",
        detail:
          "گزارش در مرورگر دوباره محاسبه شد؛ لینک خارجی، #REF! و تقسیم بر صفر وارد خروجی نشد.",
        status: "ok",
      },
    ],
  };
}

function parseReportWorkbook(workbook: XLSX.WorkBook): ParseResult | null {
  const reportName = findSheetName(workbook, "جمعیت تحت پوشش-استانی");
  if (!reportName) return null;
  const data = sheetRows(workbook.Sheets[reportName]);
  const rows: ProvinceRow[] = [];

  for (const row of data.slice(5)) {
    const code = provinceCode(row[0]);
    const name = normalizeText(row[1]);
    if (!code || !name) continue;
    rows.push({
      code,
      name,
      insuredMen: asNumber(row[2]),
      insuredWomen: asNumber(row[3]),
      insuredTotal: asNumber(row[4]),
      insuredDependents: asNumber(row[5]),
      pensionMen: asNumber(row[6]),
      pensionWomen: asNumber(row[7]),
      pensionTotal: asNumber(row[8]),
      pensionDependents: asNumber(row[9]),
      primaryMen: asNumber(row[10]),
      primaryWomen: asNumber(row[11]),
      primaryTotal: asNumber(row[12]),
      dependents: asNumber(row[13]),
      grandTotal: asNumber(row[14]),
    });
  }

  if (!rows.length) {
    throw new Error("شیت گزارش پیدا شد، اما مقادیر ذخیره‌شده قابل‌خواندن نیست.");
  }

  const title = normalizeText(data[0]?.[0]);
  const period = title.match(/در\s+(.+)$/)?.[1] || "دورهٔ ذخیره‌شده";
  return {
    rows,
    sourceMode: "report",
    period,
    checks: [
      {
        label: "حالت سازگاری",
        detail: `شیت «${reportName}» از فایل گزارش خوانده شد.`,
        status: "ok",
      },
      {
        label: "تازگی داده",
        detail:
          "این مقادیر Cache اکسل هستند. برای محاسبهٔ تازه و مستقل، فایل amar.xlsx را بارگذاری کنید.",
        status: "warn",
      },
      {
        label: "خطاهای فرمول",
        detail:
          "فقط مقادیر عددی ذخیره‌شده خوانده شد و سلول‌های خطادار در محاسبهٔ جدید استفاده نشدند.",
        status: "ok",
      },
    ],
  };
}

function parseWorkbook(workbook: XLSX.WorkBook): ParseResult {
  const source = parseSourceWorkbook(workbook);
  if (source) return source;
  const report = parseReportWorkbook(workbook);
  if (report) return report;
  throw new Error(
    "ساختار فایل شناخته نشد. amar.xlsx یا جداول آماری.xlsx را انتخاب کنید.",
  );
}

function FeaturedMetricImage() {
  return <span className="metric-story" aria-hidden="true" />;
}

function MetricCard({
  label,
  value,
  note,
  tone,
  featured = false,
  onClick,
}: {
  label: string;
  value: number;
  note: string;
  tone: "blue" | "mint" | "amber" | "violet";
  featured?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      className={`metric-card metric-${tone} drill-card ${
        featured ? "metric-featured-total" : ""
      }`}
      type="button"
      onClick={onClick}
    >
      {featured && <FeaturedMetricImage />}
      <span className="metric-card-content">
        <span className="metric-dot" aria-hidden="true" />
        <p>{label}</p>
        <strong>{numberFormat.format(value)}</strong>
        <small>{note}</small>
      </span>
      <span className="drill-hint">مشاهده ریزجزئیات ←</span>
    </button>
  );
}

function versionTypeClass(type: VersionType) {
  if (type === "رفع ایراد") return "is-fix";
  if (type === "بهبود") return "is-improvement";
  if (type === "تغییر داده یا محاسبات") return "is-data";
  if (type === "نسخه اصلی") return "is-major";
  return "is-feature";
}

function VersionBanner({
  version,
  onClick,
}: {
  version: VersionEntry;
  onClick: () => void;
}) {
  return (
    <button className="version-banner" type="button" onClick={onClick}>
      <span className="version-live-dot" aria-hidden="true" />
      <span className="version-banner-copy">
        <small>آخرین نسخه منتشرشده</small>
        <strong>{version.title}</strong>
      </span>
      <span
        className={`version-type-chip ${versionTypeClass(version.versionType)}`}
      >
        {version.versionType}
      </span>
      <span className="version-number" dir="ltr">
        v{version.version}
      </span>
      <span className="version-date">{formatReleaseDate(version.releasedAt)}</span>
      <span className="version-open">مشاهده تغییرات ←</span>
    </button>
  );
}

function VersionHistoryModal({
  versions,
  selectedVersion,
  onSelect,
  onClose,
}: {
  versions: VersionEntry[];
  selectedVersion: string;
  onSelect: (version: string) => void;
  onClose: () => void;
}) {
  const selected =
    versions.find((item) => item.version === selectedVersion) ?? versions[0];
  if (!selected) return null;

  return (
    <div
      className="version-modal-backdrop"
      role="presentation"
      onMouseDown={(event) => {
        if (event.currentTarget === event.target) onClose();
      }}
    >
      <section
        className="version-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="version-modal-title"
      >
        <header>
          <div>
            <span className="section-kicker">گزارش تغییرات</span>
            <h2 id="version-modal-title">تاریخچه نسخه‌های پوشش‌نما</h2>
            <p>نوع و شرح تغییرات هر انتشار را از اینجا بررسی کنید.</p>
          </div>
          <button type="button" onClick={onClose} aria-label="بستن تاریخچه نسخه‌ها">
            ×
          </button>
        </header>

        <div className="version-modal-layout">
          <nav className="version-timeline" aria-label="فهرست نسخه‌ها">
            {versions.map((version) => (
              <button
                className={
                  version.version === selected.version ? "is-selected" : ""
                }
                type="button"
                onClick={() => onSelect(version.version)}
                key={version.id ?? version.version}
              >
                <span dir="ltr">v{version.version}</span>
                <strong>{version.title}</strong>
                <small>{formatReleaseDate(version.releasedAt)}</small>
              </button>
            ))}
          </nav>

          <article className="version-detail">
            <div className="version-detail-heading">
              <div>
                <span
                  className={`version-type-chip ${versionTypeClass(
                    selected.versionType,
                  )}`}
                >
                  {selected.versionType}
                </span>
                <h3>{selected.title}</h3>
              </div>
              <strong dir="ltr">v{selected.version}</strong>
            </div>
            <p>{selected.summary}</p>
            <time dateTime={selected.releasedAt}>
              تاریخ انتشار: {formatReleaseDate(selected.releasedAt)}
            </time>
            <div className="version-change-list">
              {selected.changes.map((change, index) => (
                <div key={change.id ?? `${change.changeType}-${index}`}>
                  <span
                    className={`version-type-chip ${versionTypeClass(
                      change.changeType,
                    )}`}
                  >
                    {change.changeType}
                  </span>
                  <p>{change.description}</p>
                </div>
              ))}
            </div>
          </article>
        </div>

        <footer>
          <p>
            نسخه عمومی، تاریخچه منتشرشده را بدون ورود نمایش می‌دهد. مدیریت و
            ویرایش فقط برای مدیر انجام می‌شود.
          </p>
          <div className="version-footer-actions">
            <a
              className="ghost-button"
                href="https://github.com/mnikoie2005-cmd/pooshesh-nama/raw/main/pooshesh-nama-source-v1.7.2.zip"
            >
              دریافت سورس
            </a>
            <a
              className="secondary-button"
              href="https://mnikoie2005-cmd.github.io/pooshesh-nama/admin.html"
            >
              مشاهده عمومی مدیریت نسخه‌ها
            </a>
          </div>
        </footer>
      </section>
    </div>
  );
}

function BreakdownPanel({
  title,
  total,
  tone,
  items,
  onItemClick,
}: {
  title: string;
  total: number;
  tone: "insured" | "pension" | "coverage";
  items: { label: string; value: number }[];
  onItemClick: (label: string) => void;
}) {
  return (
    <article className={`breakdown-panel breakdown-${tone}`}>
      <div className="breakdown-heading">
        <button
          className="breakdown-total-button"
          type="button"
          onClick={() => onItemClick(title)}
        >
          <span>{title}</span>
          <strong>{numberFormat.format(total)}</strong>
        </button>
        {tone === "insured" ? (
          <span
            className="breakdown-heading-icon breakdown-heading-icon-insured"
            aria-label="نماد بیمه‌شده"
            role="img"
          >
            <UserRoundCheck />
          </span>
        ) : tone === "pension" ? (
          <span
            className="breakdown-heading-icon breakdown-heading-icon-pension"
            aria-label="نماد سالمند"
            role="img"
          >
            <PersonStanding />
          </span>
        ) : (
          <i aria-hidden="true" />
        )}
      </div>
      <div className="breakdown-fields">
        {items.map((item) => (
          <button
            type="button"
            onClick={() => onItemClick(item.label)}
            key={item.label}
          >
            <span>{item.label}</span>
            <strong>{numberFormat.format(item.value)}</strong>
          </button>
        ))}
      </div>
    </article>
  );
}

function EmptyDataPanel({ onOpenSettings }: { onOpenSettings: () => void }) {
  return (
    <div className="empty-data-panel">
      <span aria-hidden="true">XL</span>
      <div>
        <h3>هنوز هیچ داده‌ای وارد نشده است</h3>
        <p>
          برنامه بدون دادهٔ نمونه شروع می‌شود. فایل جامع یا شیت‌های ورودی را از
          تنظیمات اضافه کنید.
        </p>
      </div>
      <button className="primary-button" type="button" onClick={onOpenSettings}>
        رفتن به تنظیمات منابع
      </button>
    </div>
  );
}

function GeneratedReportPage({
  report,
  sourceLabels,
  period,
  initialQuery,
  onOpenSettings,
}: {
  report: GeneratedReport;
  sourceLabels: Record<string, string>;
  period: string;
  initialQuery: string;
  onOpenSettings: () => void;
}) {
  const [reportQuery, setReportQuery] = useState(initialQuery);
  const [pageNumber, setPageNumber] = useState(1);
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: "asc" | "desc";
  } | null>(null);
  const pageSize = 25;
  const groupedCoverageTable = [
    "coverage-branch",
    "coverage-treatment-province",
    "coverage-treatment-branch",
  ].includes(report.definition.id);
  const branchCoverageTable = [
    "coverage-branch",
    "coverage-treatment-branch",
  ].includes(report.definition.id);
  const filteredReportRows = useMemo(() => {
    const normalizedQuery = normalizeText(reportQuery);
    const filtered = normalizedQuery
      ? report.rows.filter((row) =>
          Object.values(row).some((value) =>
            normalizeText(value).includes(normalizedQuery),
          ),
        )
      : [...report.rows];
    if (!sortConfig) return filtered;
    const column = report.columns.find(
      (item) => item.key === sortConfig.key,
    );
    return filtered.sort((left, right) => {
      const leftValue = left[sortConfig.key];
      const rightValue = right[sortConfig.key];
      const comparison =
        column?.format === "number" || column?.format === "percent"
          ? asNumber(leftValue) - asNumber(rightValue)
          : normalizeText(leftValue).localeCompare(
              normalizeText(rightValue),
              "fa",
              { numeric: true },
            );
      return sortConfig.direction === "asc" ? comparison : -comparison;
    });
  }, [report.columns, report.rows, reportQuery, sortConfig]);
  const pageCount = Math.max(
    1,
    Math.ceil(filteredReportRows.length / pageSize),
  );
  const safePageNumber = Math.min(pageNumber, pageCount);
  const pageRows = filteredReportRows.slice(
    (safePageNumber - 1) * pageSize,
    safePageNumber * pageSize,
  );

  function exportReportCsv() {
    if (!report.rows.length) return;
    const escape = (value: unknown) =>
      `"${String(value ?? "").replace(/"/g, '""')}"`;
    const csv = [
      report.columns.map((column) => escape(column.label)).join(","),
      ...report.rows.map((row) =>
        report.columns.map((column) => escape(row[column.key])).join(","),
      ),
    ].join("\n");
    const blob = new Blob(["\uFEFF", csv], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${report.definition.title}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  function renderSortButton(key: string, label: string) {
    return (
      <button
        className="sort-button"
        type="button"
        onClick={() => {
          setSortConfig((current) =>
            current?.key === key
              ? {
                  key,
                  direction: current.direction === "asc" ? "desc" : "asc",
                }
              : { key, direction: "asc" },
          );
          setPageNumber(1);
        }}
      >
        {label}
        <span aria-hidden="true">
          {sortConfig?.key === key
            ? sortConfig.direction === "asc"
              ? "↑"
              : "↓"
            : "↕"}
        </span>
      </button>
    );
  }

  return (
    <section className="generated-report-page">
      <div className="report-page-hero">
        <div>
          <span className="section-kicker">
            {REPORT_GROUP_LABELS[report.definition.group]}
          </span>
          <h1>{report.definition.title}</h1>
          <p>{report.definition.description}</p>
          <span className="report-period">دوره آماری: {period}</span>
        </div>
        <div className={`report-readiness ${report.ready ? "is-ready" : ""}`}>
          <span aria-hidden="true">{report.ready ? "✓" : "○"}</span>
          <div>
            <strong>
              {report.ready ? "گزارش آماده است" : "منابع گزارش ناقص است"}
            </strong>
            <small>
              {report.ready
                ? `${toFaDigits(report.rows.length)} ردیف محاسبه شد`
                : `${toFaDigits(report.missingSources.length)} منبع باقی مانده`}
            </small>
          </div>
        </div>
      </div>

      {!report.ready ? (
        <div className="missing-report-sources">
          <div>
            <span className="missing-icon" aria-hidden="true">
              !
            </span>
            <div>
              <h2>برای ساخت این شیت، منابع زیر را وارد کنید</h2>
              <div className="missing-source-tags">
                {report.missingSources.map((sourceKey) => (
                  <span key={sourceKey}>
                    {sourceLabels[sourceKey] ?? sourceKey}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <button
            className="primary-button"
            type="button"
            onClick={onOpenSettings}
          >
            رفتن به تنظیمات منابع
          </button>
        </div>
      ) : (
        <>
          <div className="report-highlights">
            {report.highlights.map((highlight) => (
              <article key={highlight.label}>
                <span>{highlight.label}</span>
                <strong>
                  {highlight.format === "percent"
                    ? `${percentFormat.format(highlight.value * 100)}٪`
                    : numberFormat.format(highlight.value)}
                </strong>
              </article>
            ))}
            <article>
              <span>وضعیت محاسبه</span>
              <strong className="calculated-label">محاسبه مستقیم</strong>
            </article>
          </div>

          <div className="report-table-toolbar">
            <label className="search-box">
              <span aria-hidden="true">⌕</span>
              <input
                value={reportQuery}
                onChange={(event) => {
                  setReportQuery(event.target.value);
                  setPageNumber(1);
                }}
                placeholder="جست‌وجو در ردیف‌های گزارش"
                aria-label="جست‌وجو در گزارش"
              />
            </label>
            <button
              className="secondary-button"
              type="button"
              onClick={exportReportCsv}
            >
              دریافت CSV
            </button>
          </div>

          <div className="table-scroll-note">
            <span aria-hidden="true">↔</span>
            تمام ستون‌ها حفظ شده‌اند؛ در نمایشگر کوچک جدول را حرکت دهید.
          </div>
          <div className="table-wrap generated-table-wrap">
            <table className="generated-report-table">
              {groupedCoverageTable ? (
                <thead>
                  <tr className="group-head">
                    <th rowSpan={3} className="head-code">
                      {renderSortButton("provinceCode", "کد استان")}
                    </th>
                    <th rowSpan={3} className="head-office">
                      {renderSortButton("provinceName", "اداره کل")}
                    </th>
                    {branchCoverageTable && (
                      <>
                        <th rowSpan={3} className="head-code">
                          {renderSortButton("branchCode", "کد شعبه")}
                        </th>
                        <th rowSpan={3} className="head-office">
                          {renderSortButton("branchName", "نام شعبه")}
                        </th>
                      </>
                    )}
                    <th colSpan={4} className="head-insured">
                      بیمه‌شدگان
                    </th>
                    <th colSpan={4} className="head-pension">
                      مستمری‌بگیران
                    </th>
                    <th colSpan={5} className="head-coverage">
                      جمعیت تحت پوشش
                    </th>
                  </tr>
                  <tr className="subgroup-head">
                    <th colSpan={3} className="head-insured">
                      بیمه‌شده اصلی
                    </th>
                    <th rowSpan={2} className="head-insured">
                      {renderSortButton(
                        "insuredDependents",
                        "بیمه‌شده تبعی",
                      )}
                    </th>
                    <th colSpan={3} className="head-pension">
                      مستمری‌بگیر اصلی
                    </th>
                    <th rowSpan={2} className="head-pension">
                      {renderSortButton(
                        "pensionDependents",
                        "مستمری‌بگیر تبعی",
                      )}
                    </th>
                    <th colSpan={3} className="head-coverage">
                      اصلی
                    </th>
                    <th rowSpan={2} className="head-coverage">
                      {renderSortButton("dependents", "تبعی")}
                    </th>
                    <th rowSpan={2} className="head-total">
                      {renderSortButton("grandTotal", "جمع کل")}
                    </th>
                  </tr>
                  <tr className="field-head">
                    {[
                      ["insuredMen", "مرد"],
                      ["insuredWomen", "زن"],
                      ["insuredTotal", "جمع"],
                    ].map(([key, label]) => (
                      <th className="head-insured" key={key}>
                        {renderSortButton(key, label)}
                      </th>
                    ))}
                    {[
                      ["pensionMen", "مرد"],
                      ["pensionWomen", "زن"],
                      ["pensionTotal", "جمع"],
                    ].map(([key, label]) => (
                      <th className="head-pension" key={key}>
                        {renderSortButton(key, label)}
                      </th>
                    ))}
                    {[
                      ["primaryMen", "مرد"],
                      ["primaryWomen", "زن"],
                      ["primaryTotal", "جمع"],
                    ].map(([key, label]) => (
                      <th className="head-coverage" key={key}>
                        {renderSortButton(key, label)}
                      </th>
                    ))}
                  </tr>
                </thead>
              ) : (
                <thead>
                  <tr>
                    {report.columns.map((column) => (
                      <th key={column.key}>
                        {renderSortButton(column.key, column.label)}
                      </th>
                    ))}
                  </tr>
                </thead>
              )}
              <tbody>
                {pageRows.map((row, rowIndex) => (
                  <tr key={`${safePageNumber}-${rowIndex}`}>
                    {report.columns.map((column) => {
                      const value = row[column.key];
                      return (
                        <td key={column.key}>
                          {column.format === "number"
                            ? numberFormat.format(asNumber(value))
                            : column.format === "percent"
                              ? `${percentFormat.format(asNumber(value) * 100)}٪`
                              : column.key.toLowerCase().includes("code")
                                ? toFaDigits(value)
                                : value}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
            {!pageRows.length && (
              <div className="empty-state">ردیفی برای نمایش پیدا نشد.</div>
            )}
          </div>

          <div className="pagination">
            <button
              type="button"
              disabled={safePageNumber === 1}
              onClick={() => setPageNumber((current) => current - 1)}
            >
              صفحه قبل
            </button>
            <span>
              صفحه {toFaDigits(safePageNumber)} از {toFaDigits(pageCount)}
              <small>
                {toFaDigits(filteredReportRows.length)} ردیف
              </small>
            </span>
            <button
              type="button"
              disabled={safePageNumber === pageCount}
              onClick={() => setPageNumber((current) => current + 1)}
            >
              صفحه بعد
            </button>
          </div>

          <p className="report-calculation-note">{report.note}</p>
        </>
      )}
    </section>
  );
}

export default function Home() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [activePage, setActivePage] = useState<AppPage>("home");
  const [pageHistory, setPageHistory] = useState<AppPage[]>([]);
  const [reportInitialQuery, setReportInitialQuery] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [loadedFiles, setLoadedFiles] = useState<LoadedWorkbook[]>([]);
  const [rows, setRows] = useState<ProvinceRow[]>([]);
  const [summary, setSummary] = useState<Summary>(EMPTY_SUMMARY);
  const [checks, setChecks] = useState<CheckItem[]>([
    {
      label: "در انتظار فایل",
      detail: "برای شروع، فایل مرجع یا شیت‌های ورودی را از تنظیمات اضافه کنید.",
      status: "warn",
    },
  ]);
  const [fileName, setFileName] = useState("هنوز فایلی وارد نشده");
  const [period, setPeriod] = useState("دوره نامشخص");
  const [mode, setMode] = useState<"empty" | "source" | "report">("empty");
  const [query, setQuery] = useState("");
  const [provincePage, setProvincePage] = useState(1);
  const [provinceSort, setProvinceSort] = useState<{
    key: keyof ProvinceRow;
    direction: "asc" | "desc";
  }>({ key: "grandTotal", direction: "desc" });
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [versions, setVersions] = useState<VersionEntry[]>(
    DEFAULT_VERSION_HISTORY,
  );
  const [selectedVersion, setSelectedVersion] = useState(
    DEFAULT_VERSION_HISTORY[0].version,
  );
  const [versionModalOpen, setVersionModalOpen] = useState(false);

  useEffect(() => {
    if (
      window.location.protocol === "file:" ||
      window.location.hostname.endsWith("github.io")
    ) {
      return;
    }
    const controller = new AbortController();
    void fetch("/api/versions", {
      cache: "no-store",
      signal: controller.signal,
    })
      .then(async (response) => {
        if (!response.ok) throw new Error("نسخه‌های پایگاه داده در دسترس نیست.");
        return (await response.json()) as { versions?: VersionEntry[] };
      })
      .then((result) => {
        if (result.versions?.length) {
          setVersions(result.versions);
          setSelectedVersion(result.versions[0].version);
        }
      })
      .catch((fetchError: unknown) => {
        if (
          !(fetchError instanceof DOMException) ||
          fetchError.name !== "AbortError"
        ) {
          console.warn(fetchError);
        }
      });
    return () => controller.abort();
  }, []);

  const sourceLabels = useMemo(
    () =>
      Object.fromEntries(
        SOURCE_REQUIREMENTS.map((source) => [source.key, source.title]),
      ),
    [],
  );
  const matchesBySource = useMemo(
    () => sourceMatches(loadedFiles),
    [loadedFiles],
  );
  const sourceRowsByKey = useMemo<SourceRows>(() => {
    const active = activeSourceMap(loadedFiles);
    const output: SourceRows = {};
    for (const [sourceKey, source] of active) {
      output[sourceKey] = sheetRows(
        source.workbook.Sheets[source.sheetName],
      );
    }
    return output;
  }, [loadedFiles]);
  const activeGeneratedReport = useMemo(() => {
    if (!isReportPage(activePage) || activePage === "coverage-province") {
      return null;
    }
    return buildGeneratedReport(activePage, sourceRowsByKey);
  }, [activePage, sourceRowsByKey]);
  const activeReportPeriod = useMemo(
    () => {
      if (!isReportPage(activePage)) return period;
      const detected = detectReportPeriod(activePage, sourceRowsByKey);
      return detected === "پس از ورود فایل مشخص می‌شود" && mode !== "empty"
        ? period
        : detected;
    },
    [activePage, mode, period, sourceRowsByKey],
  );
  const readyCoreCount = CURRENT_REPORT_REQUIREMENTS.filter(
    (source) => (matchesBySource.get(source.key)?.length ?? 0) > 0,
  ).length;
  const readySourceCount = SOURCE_REQUIREMENTS.filter(
    (source) => (matchesBySource.get(source.key)?.length ?? 0) > 0,
  ).length;
  const currentReportReady =
    readyCoreCount === CURRENT_REPORT_REQUIREMENTS.length;

  const filteredRows = useMemo(() => {
    const normalizedQuery = normalizeText(query);
    return rows
      .filter(
        (row) =>
          !normalizedQuery ||
          normalizeText(row.name).includes(normalizedQuery) ||
          row.code.includes(normalizedQuery),
      )
      .sort((a, b) => {
        const left = a[provinceSort.key];
        const right = b[provinceSort.key];
        const comparison =
          typeof left === "number" && typeof right === "number"
            ? left - right
            : normalizeText(left).localeCompare(normalizeText(right), "fa", {
                numeric: true,
              });
        return provinceSort.direction === "asc" ? comparison : -comparison;
      });
  }, [provinceSort, query, rows]);
  const provincePageSize = 20;
  const provincePageCount = Math.max(
    1,
    Math.ceil(filteredRows.length / provincePageSize),
  );
  const pagedProvinceRows = filteredRows.slice(
    (provincePage - 1) * provincePageSize,
    provincePage * provincePageSize,
  );

  const topRows = useMemo(
    () => [...rows].sort((a, b) => b.grandTotal - a.grandTotal).slice(0, 6),
    [rows],
  );
  const maxPopulation = topRows[0]?.grandTotal || 1;
  const dependentShare = summary.grandTotal
    ? (summary.dependents / summary.grandTotal) * 100
    : 0;
  const primaryShare = summary.grandTotal
    ? (summary.primaryTotal / summary.grandTotal) * 100
    : 0;

  function navigateTo(page: AppPage, initialQuery = "") {
    if (page !== activePage) {
      setPageHistory((history) => [...history, activePage]);
    }
    setActivePage(page);
    setReportInitialQuery(initialQuery);
    if (page === "coverage-province") {
      setQuery(initialQuery);
      setProvincePage(1);
    }
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goBack() {
    const previous = pageHistory.at(-1) ?? "home";
    setPageHistory((history) => history.slice(0, -1));
    setActivePage(previous);
    setReportInitialQuery("");
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function applyLoadedSources(nextFiles: LoadedWorkbook[]) {
    const rawResult = parseRawSourceFiles(nextFiles);
    let result = rawResult;
    let reportFileName = "";

    if (!result) {
      for (const file of [...nextFiles].reverse()) {
        try {
          const compatibilityResult = parseWorkbook(file.workbook);
          result = compatibilityResult;
          reportFileName = file.fileName;
          break;
        } catch {
          // فایل می‌تواند فقط بخشی از منابع را داشته باشد؛ در این مرحله خطا نیست.
        }
      }
    }

    if (result) {
      setRows(result.rows);
      setSummary(summarize(result.rows));
      setChecks(result.checks);
      setPeriod(result.period);
      setMode(result.sourceMode);
      setFileName(
        rawResult
          ? nextFiles.length === 1
            ? nextFiles[0].fileName
            : `${toFaDigits(nextFiles.length)} فایل منبع`
          : reportFileName,
      );
      setQuery("");
      setProvincePage(1);
      return;
    }

    const nextMatches = sourceMatches(nextFiles);
    const nextCoreReady = CURRENT_REPORT_REQUIREMENTS.filter(
      (source) => (nextMatches.get(source.key)?.length ?? 0) > 0,
    ).length;
    setRows([]);
    setSummary(EMPTY_SUMMARY);
    setPeriod("در انتظار تکمیل منابع");
    setMode("empty");
    setFileName(
      nextFiles.length
        ? `${toFaDigits(nextFiles.length)} فایل؛ ورودی ناقص`
        : "هنوز فایلی وارد نشده",
    );
    setChecks(
      nextFiles.length
        ? [
            {
              label: "منابع اصلی ناقص است",
              detail: `${toFaDigits(nextCoreReady)} از ${toFaDigits(CURRENT_REPORT_REQUIREMENTS.length)} شیت لازم شناسایی شده است.`,
              status: "warn",
            },
          ]
        : [
            {
              label: "در انتظار فایل",
              detail:
                "برای شروع، فایل مرجع یا شیت‌های ورودی را از تنظیمات اضافه کنید.",
              status: "warn",
            },
          ],
    );
  }

  async function loadFiles(fileList: File[], expectedSourceKey?: string) {
    if (!fileList.length) return;
    const validFiles = fileList.filter((file) => /\.(xlsx|xls)$/i.test(file.name));
    const invalidCount = fileList.length - validFiles.length;
    if (!validFiles.length) {
      setError("لطفاً فایل اکسل با پسوند xlsx یا xls انتخاب کنید.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const parsedFiles: LoadedWorkbook[] = [];
      for (const file of validFiles) {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, {
          type: "array",
          cellDates: false,
          cellFormula: true,
        });
        parsedFiles.push({
          id: `${file.name}-${file.size}-${file.lastModified}`,
          fileName: file.name,
          size: file.size,
          workbook,
          recognizedSheets: SOURCE_REQUIREMENTS.filter((source) =>
            findSheetName(workbook, source.sheetName),
          ).map((source) => source.sheetName),
        });
      }

      if (expectedSourceKey) {
        const expectedSource = SOURCE_REQUIREMENTS.find(
          (source) => source.key === expectedSourceKey,
        );
        const expectedSheetFound =
          expectedSource &&
          parsedFiles.some((file) =>
            findSheetName(file.workbook, expectedSource.sheetName),
          );
        if (expectedSource && !expectedSheetFound) {
          setError(
            `این فایل برای «${expectedSource.title}» قابل استفاده نیست؛ شیت «${expectedSource.sheetName}» داخل آن پیدا نشد.`,
          );
          return;
        }
      }

      const incomingIds = new Set(parsedFiles.map((file) => file.id));
      const nextFiles = [
        ...loadedFiles.filter((file) => !incomingIds.has(file.id)),
        ...parsedFiles,
      ];
      setLoadedFiles(nextFiles);
      applyLoadedSources(nextFiles);
      if (invalidCount) {
        setError(
          `${toFaDigits(invalidCount)} فایل غیر اکسل نادیده گرفته شد.`,
        );
      }
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : "خواندن فایل با خطا روبه‌رو شد.",
      );
    } finally {
      setBusy(false);
    }
  }

  function onFileChange(event: ChangeEvent<HTMLInputElement>) {
    void loadFiles(Array.from(event.target.files ?? []));
    event.target.value = "";
  }

  function onDrop(event: DragEvent<HTMLDivElement>) {
    event.preventDefault();
    setDragging(false);
    void loadFiles(Array.from(event.dataTransfer.files));
  }

  function removeLoadedFile(fileId: string) {
    const nextFiles = loadedFiles.filter((file) => file.id !== fileId);
    setLoadedFiles(nextFiles);
    setError("");
    applyLoadedSources(nextFiles);
  }

  function clearLoadedFiles() {
    setLoadedFiles([]);
    setError("");
    applyLoadedSources([]);
  }

  function exportCsv() {
    const headers = [
      "کد اداره کل",
      "اداره کل",
      "بیمه‌شده اصلی مرد",
      "بیمه‌شده اصلی زن",
      "جمع بیمه‌شده اصلی",
      "بیمه‌شده تبعی",
      "مستمری‌بگیر اصلی مرد",
      "مستمری‌بگیر اصلی زن",
      "جمع مستمری‌بگیر اصلی",
      "مستمری‌بگیر تبعی",
      "جمعیت اصلی مرد",
      "جمعیت اصلی زن",
      "جمع جمعیت اصلی",
      "جمعیت تبعی",
      "جمع کل جمعیت تحت پوشش",
    ];
    const lines = rows.map((row) =>
      [
        row.code,
        row.name,
        row.insuredMen,
        row.insuredWomen,
        row.insuredTotal,
        row.insuredDependents,
        row.pensionMen,
        row.pensionWomen,
        row.pensionTotal,
        row.pensionDependents,
        row.primaryMen,
        row.primaryWomen,
        row.primaryTotal,
        row.dependents,
        row.grandTotal,
      ]
        .map((value) => `"${String(value).replace(/"/g, '""')}"`)
        .join(","),
    );
    const blob = new Blob(["\ufeff", [headers.join(","), ...lines].join("\n")], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "jamiyat-taht-poshesh.csv";
    anchor.click();
    URL.revokeObjectURL(url);
  }

  function renderProvinceSortButton(
    key: keyof ProvinceRow,
    label: string,
  ) {
    return (
      <button
        className="sort-button"
        type="button"
        onClick={() => {
          setProvinceSort((current) =>
            current.key === key
              ? {
                  key,
                  direction: current.direction === "asc" ? "desc" : "asc",
                }
              : { key, direction: "asc" },
          );
          setProvincePage(1);
        }}
      >
        {label}
        <span aria-hidden="true">
          {provinceSort.key === key
            ? provinceSort.direction === "asc"
              ? "↑"
              : "↓"
            : "↕"}
        </span>
      </button>
    );
  }

  return (
    <main>
      <header className="topbar">
        <button
          className="brand brand-button"
          type="button"
          onClick={() => navigateTo("home")}
          aria-label="پوشش‌نما، صفحه اصلی"
        >
          <span className="brand-mark" aria-hidden="true">
            پ
          </span>
          <span>
            <strong>پوشش‌نما</strong>
            <small>تحلیل آمار تأمین اجتماعی</small>
          </span>
        </button>
        <nav className="desktop-nav" aria-label="ناوبری اصلی">
          <button type="button" onClick={() => navigateTo("home")}>
            خانه
          </button>
          <button type="button" onClick={() => navigateTo("dashboard")}>
            داشبورد
          </button>
          <button type="button" onClick={() => navigateTo("settings")}>
            تنظیمات منابع
          </button>
        </nav>
        <div className="topbar-actions">
          <div className="privacy-pill">
            <span aria-hidden="true">●</span>
            پردازش کاملاً محلی
          </div>
          {activePage !== "home" && (
            <button
              className="header-back-button"
              type="button"
              onClick={goBack}
              aria-label="بازگشت به صفحه قبل"
            >
              <span aria-hidden="true">→</span>
              بازگشت
            </button>
          )}
          <button
            className={`menu-toggle ${menuOpen ? "is-open" : ""}`}
            type="button"
            onClick={() => setMenuOpen((open) => !open)}
            aria-expanded={menuOpen}
            aria-controls="app-menu"
            aria-label={menuOpen ? "بستن منو" : "باز کردن منو"}
          >
            <i />
            <i />
            <i />
          </button>
        </div>
      </header>

      <button
        className={`menu-backdrop ${menuOpen ? "is-visible" : ""}`}
        type="button"
        onClick={() => setMenuOpen(false)}
        aria-label="بستن منو"
      />
      <aside
        className={`app-drawer ${menuOpen ? "is-open" : ""}`}
        id="app-menu"
        aria-hidden={!menuOpen}
      >
        <div className="drawer-heading">
          <div className="brand">
            <span className="brand-mark" aria-hidden="true">
              پ
            </span>
            <span>
              <strong>فهرست صفحات</strong>
              <small>{toFaDigits(REPORTS.length)} شیت گزارش</small>
            </span>
          </div>
          <button
            type="button"
            onClick={() => setMenuOpen(false)}
            aria-label="بستن فهرست"
          >
            ×
          </button>
        </div>
        <div className="drawer-main-links">
          <button
            className={activePage === "home" ? "is-active" : ""}
            type="button"
            onClick={() => navigateTo("home")}
          >
            <span aria-hidden="true">⌂</span>
            خانه و فهرست گزارش‌ها
          </button>
          <button
            className={activePage === "dashboard" ? "is-active" : ""}
            type="button"
            onClick={() => navigateTo("dashboard")}
          >
            <span aria-hidden="true">◫</span>
            داشبورد ملی
          </button>
          <button
            className={activePage === "settings" ? "is-active" : ""}
            type="button"
            onClick={() => navigateTo("settings")}
          >
            <span aria-hidden="true">⚙</span>
            تنظیمات و منابع
            <small>
              {toFaDigits(readySourceCount)}/{toFaDigits(SOURCE_REQUIREMENTS.length)}
            </small>
          </button>
        </div>
        <div className="drawer-report-list">
          {Object.entries(REPORT_GROUP_LABELS).map(([group, label]) => (
            <div className="drawer-report-group" key={group}>
              <strong>{label}</strong>
              {REPORTS.filter((report) => report.group === group).map(
                (report) => {
                  const ready = report.sourceKeys.every(
                    (sourceKey) => (sourceRowsByKey[sourceKey]?.length ?? 0) > 1,
                  );
                  return (
                    <button
                      className={activePage === report.id ? "is-active" : ""}
                      type="button"
                      onClick={() => navigateTo(report.id)}
                      key={report.id}
                    >
                      <span
                        className={`drawer-status ${ready ? "is-ready" : ""}`}
                        aria-hidden="true"
                      >
                        {ready ? "✓" : "○"}
                      </span>
                      {report.title}
                    </button>
                  );
                },
              )}
            </div>
          ))}
        </div>
      </aside>

      <section
        className={`hero ${activePage === "home" ? "" : "page-hidden"}`}
        id="top"
      >
        <div className="hero-copy">
          <div className="eyebrow">گزارش جمعیت تحت پوشش — نسخهٔ وب</div>
          <h1>
            از فایل اکسل،
            <br />
            <span>تا گزارش قابل اتکا.</span>
          </h1>
          <p>
            یک فایل جامع یا چند فایل جداگانه را انتخاب کنید؛ شیت‌های منبع
            خودکار شناسایی و در همین مرورگر با هم تجمیع می‌شوند.
          </p>
          <div className="hero-facts">
            <span>✓ کنترل خودکار جمع‌ها</span>
            <span>✓ حذف وابستگی به Cache اکسل</span>
            <span>✓ خروجی CSV</span>
          </div>
        </div>

        <div
          className={`upload-card ${dragging ? "is-dragging" : ""}`}
          onDragEnter={(event) => {
            event.preventDefault();
            setDragging(true);
          }}
          onDragOver={(event) => event.preventDefault()}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
        >
          <div className="upload-icon" aria-hidden="true">
            ↑
          </div>
          <strong>
            {busy ? "در حال خواندن منابع…" : "فایل یا فایل‌های اکسل را اینجا رها کنید"}
          </strong>
          <p>یک فایل چندشیتی یا چند فایل مستقل</p>
          <button
            className="primary-button"
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={busy}
          >
            انتخاب فایل‌ها
          </button>
          <input
            ref={inputRef}
            className="visually-hidden"
            type="file"
            accept=".xlsx,.xls"
            multiple
            onChange={onFileChange}
            aria-label="انتخاب یک یا چند فایل اکسل"
          />
          <small>فایل شما از دستگاه خارج نمی‌شود.</small>
          {error && <div className="upload-error">{error}</div>}
        </div>
      </section>

      <section
        className={`report-catalog ${
          activePage === "home" ? "" : "page-hidden"
        }`}
      >
        <div className="section-heading">
          <div>
            <span className="section-kicker">شیت‌های خروجی</span>
            <h2>هر گزارش، یک صفحه مستقل</h2>
          </div>
          <p>
            گزارش موردنظر را باز کنید؛ منابع لازم و وضعیت آماده‌بودن آن همان‌جا
            نمایش داده می‌شود.
          </p>
        </div>
        <div className="report-card-grid">
          {REPORTS.map((report) => {
            const ready = report.sourceKeys.every(
              (sourceKey) => (sourceRowsByKey[sourceKey]?.length ?? 0) > 1,
            );
            return (
              <button
                className={`report-card ${ready ? "is-ready" : ""}`}
                type="button"
                onClick={() => navigateTo(report.id)}
                key={report.id}
              >
                <span className="report-card-group">
                  {REPORT_GROUP_LABELS[report.group]}
                </span>
                <strong>{report.title}</strong>
                <p>{report.description}</p>
                <span className="report-card-status">
                  {ready ? "✓ آماده نمایش" : "در انتظار منبع"}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <section
        className={`source-settings ${
          activePage === "settings" ? "" : "page-hidden"
        }`}
        id="settings"
      >
        <div className="section-heading settings-heading">
          <div>
            <span className="section-kicker">تنظیمات منابع</span>
            <h2>ورودی‌ها را یکجا یا جداگانه اضافه کنید</h2>
          </div>
          <div
            className={`source-progress ${
              readySourceCount === SOURCE_REQUIREMENTS.length
                ? "is-complete"
                : ""
            }`}
          >
            <span>
              <strong>
                {toFaDigits(readySourceCount)}/
                {toFaDigits(SOURCE_REQUIREMENTS.length)}
              </strong>
              کل منابع ورودی
            </span>
            <div aria-hidden="true">
              <i
                style={{
                  width: `${(readySourceCount / SOURCE_REQUIREMENTS.length) * 100}%`,
                }}
              />
            </div>
            <small className={currentReportReady ? "core-ready" : ""}>
              {currentReportReady
                ? "✓ گزارش فعلی: ۳ از ۳ کامل"
                : `گزارش فعلی: ${toFaDigits(readyCoreCount)} از ${toFaDigits(CURRENT_REPORT_REQUIREMENTS.length)}`}
            </small>
          </div>
        </div>

        <div className="settings-intro">
          <div>
            <strong>دو روش ورودی، یک نتیجه</strong>
            <p>
              برای ورود یکجا از دکمه بالا استفاده کنید؛ برای ورود تکی، دکمه روی
              کارت همان منبع را بزنید. معیار شناسایی، نام شیت است.
            </p>
          </div>
          <div className="settings-actions">
            <button
              className="primary-button"
              type="button"
              onClick={() => inputRef.current?.click()}
              disabled={busy}
            >
              افزودن فایل اکسل
            </button>
            {loadedFiles.length > 0 && (
              <button
                className="ghost-button"
                type="button"
                onClick={clearLoadedFiles}
                disabled={busy}
              >
                پاک‌کردن همه
              </button>
            )}
          </div>
        </div>

        <div className="source-status-summary">
          <span>
            فایل‌ها را یکجا یا از کارت هر منبع به‌صورت تکی اضافه کنید
          </span>
          <span className={currentReportReady ? "summary-ready" : "summary-waiting"}>
            {currentReportReady
              ? "✓ گزارش جمعیت تحت پوشش آماده است"
              : "برای ساخت گزارش، سه منبع اصلی را کامل کنید"}
          </span>
        </div>

        <div className="source-requirements">
          {SOURCE_REQUIREMENTS.map((source) => {
            const matches = matchesBySource.get(source.key) ?? [];
            const ready = matches.length > 0;
            const duplicate = matches.length > 1;
            const selected = matches.at(-1);
            return (
              <article
                className={`source-requirement ${
                  ready ? "is-ready" : "is-pending"
                } ${duplicate ? "is-duplicate" : ""}`}
                key={source.key}
              >
                <span className="requirement-check" aria-hidden="true">
                  {ready ? "✓" : "○"}
                </span>
                <div>
                  <div className="requirement-title">
                    <strong>{source.title}</strong>
                    {source.requiredForCurrentReport && (
                      <span>لازم برای گزارش فعلی</span>
                    )}
                  </div>
                  <p>{source.description}</p>
                  <small>
                    شیت «{source.sheetName}»
                    {ready && selected
                      ? ` — ${duplicate ? `${toFaDigits(matches.length)} منبع؛ منتخب: ` : ""}${selected.fileName}`
                      : " — هنوز وارد نشده"}
                  </small>
                  <label className="single-source-upload">
                    {ready
                      ? "جایگزینی فایل همین منبع"
                      : "انتخاب فایل همین منبع"}
                    <input
                      className="visually-hidden"
                      type="file"
                      accept=".xlsx,.xls"
                      disabled={busy}
                      onChange={(event) => {
                        const file = event.target.files?.[0];
                        if (file) void loadFiles([file], source.key);
                        event.target.value = "";
                      }}
                      aria-label={`انتخاب فایل برای شیت ${source.sheetName}`}
                    />
                  </label>
                </div>
              </article>
            );
          })}
        </div>

        {loadedFiles.length > 0 && (
          <div className="loaded-files-panel">
            <div className="loaded-files-heading">
              <div>
                <span className="section-kicker">فایل‌های افزوده‌شده</span>
                <h3>{toFaDigits(loadedFiles.length)} فایل در این نشست</h3>
              </div>
              <small>در صورت تکرار یک شیت، جدیدترین فایل استفاده می‌شود.</small>
            </div>
            <div className="loaded-files-list">
              {loadedFiles.map((file) => (
                <div className="loaded-file" key={file.id}>
                  <span className="file-type" aria-hidden="true">
                    XL
                  </span>
                  <div>
                    <strong>{file.fileName}</strong>
                    <p>
                      {file.recognizedSheets.length
                        ? `${toFaDigits(file.recognizedSheets.length)} شیت منبع شناسایی شد`
                        : "شیت منبع شناخته‌شده‌ای ندارد"}
                    </p>
                    <div className="recognized-tags">
                      {file.recognizedSheets.map((sheetName) => (
                        <span key={sheetName}>{sheetName}</span>
                      ))}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeLoadedFile(file.id)}
                    aria-label={`حذف فایل ${file.fileName}`}
                  >
                    حذف
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      <section
        className={`dashboard-shell ${
          activePage === "dashboard" ? "" : "page-hidden"
        }`}
        id="dashboard"
      >
        <div className="section-heading">
          <div>
            <span className="section-kicker">نمای ملی</span>
            <h2>جمعیت تحت پوشش سازمان</h2>
            <p className="dashboard-period-title">
              {formatDashboardPeriod(period)}
            </p>
          </div>
          <div className="file-status">
            <span className={`status-light status-${mode}`} />
            <span>
              <strong>{fileName}</strong>
              <small>{period}</small>
            </span>
          </div>
        </div>

        {versions[0] && (
          <VersionBanner
            version={versions[0]}
            onClick={() => {
              setSelectedVersion(versions[0].version);
              setVersionModalOpen(true);
            }}
          />
        )}

        {!rows.length ? (
          <EmptyDataPanel onOpenSettings={() => navigateTo("settings")} />
        ) : (
          <>
          <div className="metrics-grid">
          <MetricCard
            label="جمعیت کل تحت پوشش (بیمه‌شده/مستمری‌بگیر اصلی و تبعی)"
            value={summary.grandTotal}
            note="اصلی و تبعی"
            tone="blue"
            featured
            onClick={() => navigateTo("coverage-province")}
          />
          <MetricCard
            label="جمعیت اصلی (بیمه‌شده / مستمری‌بگیر)"
            value={summary.primaryTotal}
            note={`${numberFormat.format(summary.insuredTotal)} بیمه‌شده + ${numberFormat.format(summary.pensionTotal)} مستمری‌بگیر | ${percentFormat.format(primaryShare)}٪ از کل پوشش`}
            tone="mint"
            onClick={() => navigateTo("coverage-province")}
          />
          <MetricCard
            label="جمعیت تبعی (بیمه‌شده / مستمری‌بگیر)"
            value={summary.dependents}
            note={`${numberFormat.format(summary.insuredDependents)} بیمه‌شده + ${numberFormat.format(summary.pensionDependents)} مستمری‌بگیر | ${percentFormat.format(dependentShare)}٪ از کل پوشش`}
            tone="amber"
            onClick={() => navigateTo("coverage-province")}
          />
        </div>

        <div className="breakdown-grid">
          <BreakdownPanel
            title="جمعیت تحت پوشش"
            total={summary.grandTotal}
            tone="coverage"
            items={[
              { label: "بیمه‌شده اصلی مرد", value: summary.primaryMen },
              { label: "بیمه‌شده اصلی زن", value: summary.primaryWomen },
              {
                label: "جمع بیمه‌شده اصلی (زن و مرد)",
                value: summary.primaryTotal,
              },
              {
                label: "جمع بیمه‌شده تبعی (زن و مرد)",
                value: summary.dependents,
              },
            ]}
            onItemClick={() => navigateTo("coverage-province")}
          />
          <BreakdownPanel
            title="بیمه‌شدگان"
            total={summary.insuredTotal + summary.insuredDependents}
            tone="insured"
            items={[
              { label: "بیمه‌شده اصلی مرد", value: summary.insuredMen },
              { label: "بیمه‌شده اصلی زن", value: summary.insuredWomen },
              {
                label: "جمع بیمه‌شده اصلی (زن و مرد)",
                value: summary.insuredTotal,
              },
              {
                label: "جمع بیمه‌شده تبعی (زن و مرد)",
                value: summary.insuredDependents,
              },
            ]}
            onItemClick={() => navigateTo("insured-current")}
          />
          <BreakdownPanel
            title="مستمری‌بگیران"
            total={summary.pensionTotal + summary.pensionDependents}
            tone="pension"
            items={[
              { label: "بیمه‌شده اصلی مرد", value: summary.pensionMen },
              { label: "بیمه‌شده اصلی زن", value: summary.pensionWomen },
              {
                label: "جمع بیمه‌شده اصلی (زن و مرد)",
                value: summary.pensionTotal,
              },
              {
                label: "جمع بیمه‌شده تبعی (زن و مرد)",
                value: summary.pensionDependents,
              },
            ]}
            onItemClick={() => navigateTo("pension-current")}
          />
        </div>

        <div className="insight-grid">
          <article className="chart-card">
            <div className="card-heading">
              <div>
                <span className="section-kicker">بیشترین جمعیت</span>
                <h3>شش اداره کل نخست</h3>
              </div>
              <span className="legend">
                <i />
                جمع کل
              </span>
            </div>
            <div className="bar-list">
              {topRows.map((row, index) => (
                <button
                  className="bar-row drill-bar-row"
                  type="button"
                  onClick={() => navigateTo("coverage-province", row.name)}
                  key={row.code}
                >
                  <span className="bar-rank">{toFaDigits(index + 1)}</span>
                  <span className="bar-label">{row.name}</span>
                  <div className="bar-track">
                    <span
                      className="bar-fill"
                      style={{
                        width: `${Math.max(8, (row.grandTotal / maxPopulation) * 100)}%`,
                      }}
                    />
                  </div>
                  <strong>{numberFormat.format(row.grandTotal)}</strong>
                </button>
              ))}
            </div>
          </article>

          <aside className="quality-card">
            <div className="card-heading">
              <div>
                <span className="section-kicker">کنترل کیفیت</span>
                <h3>سلامت ورودی</h3>
              </div>
              <span className="quality-score">
                {toFaDigits(checks.filter((item) => item.status === "ok").length)}
                /{toFaDigits(checks.length)}
              </span>
            </div>
            <div className="check-list">
              {checks.map((check) => (
                <div className={`check-item check-${check.status}`} key={check.label}>
                  <span aria-hidden="true">{check.status === "ok" ? "✓" : "!"}</span>
                  <div>
                    <strong>{check.label}</strong>
                    <p>{check.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </aside>
        </div>
          </>
        )}
      </section>

      <section
        className={`provinces-section ${
          activePage === "coverage-province" ? "" : "page-hidden"
        }`}
        id="provinces"
      >
        <div className="section-heading">
          <div>
            <span className="section-kicker">جدول استان‌ها</span>
            <h2>جمعیت تحت پوشش-استانی</h2>
            <span className="report-period">
              دوره آماری: {activeReportPeriod}
            </span>
          </div>
          {rows.length > 0 && <div className="table-actions">
            <label className="search-box">
              <span aria-hidden="true">⌕</span>
              <input
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setProvincePage(1);
                }}
                placeholder="جست‌وجوی استان یا کد"
                aria-label="جست‌وجوی استان یا کد"
              />
            </label>
            <button type="button" className="secondary-button" onClick={exportCsv}>
              دریافت CSV
            </button>
          </div>}
        </div>

        {!rows.length ? (
          <EmptyDataPanel onOpenSettings={() => navigateTo("settings")} />
        ) : (
          <>
        <div className="table-scroll-note">
          <span aria-hidden="true">↔</span>
          در نمایشگرهای کوچک، جدول را به طرفین حرکت دهید؛ هیچ ستونی حذف نمی‌شود.
        </div>
        <div className="table-wrap">
          <table className="coverage-table">
            <thead>
              <tr className="group-head">
                <th rowSpan={3} className="head-code">
                  {renderProvinceSortButton("code", "کد اداره کل")}
                </th>
                <th rowSpan={3} className="head-office">
                  {renderProvinceSortButton("name", "اداره کل")}
                </th>
                <th colSpan={4} className="head-insured">بیمه‌شدگان</th>
                <th colSpan={4} className="head-pension">مستمری‌بگیران</th>
                <th colSpan={5} className="head-coverage">جمعیت تحت پوشش</th>
              </tr>
              <tr className="subgroup-head">
                <th colSpan={3} className="head-insured">بیمه‌شده اصلی</th>
                <th rowSpan={2} className="head-insured">
                  {renderProvinceSortButton(
                    "insuredDependents",
                    "بیمه‌شده تبعی",
                  )}
                </th>
                <th colSpan={3} className="head-pension">مستمری‌بگیر اصلی</th>
                <th rowSpan={2} className="head-pension">
                  {renderProvinceSortButton(
                    "pensionDependents",
                    "مستمری‌بگیر تبعی",
                  )}
                </th>
                <th colSpan={3} className="head-coverage">اصلی</th>
                <th rowSpan={2} className="head-coverage">
                  {renderProvinceSortButton("dependents", "تبعی")}
                </th>
                <th rowSpan={2} className="head-total">
                  {renderProvinceSortButton("grandTotal", "جمع کل")}
                </th>
              </tr>
              <tr className="field-head">
                <th className="head-insured">
                  {renderProvinceSortButton("insuredMen", "مرد")}
                </th>
                <th className="head-insured">
                  {renderProvinceSortButton("insuredWomen", "زن")}
                </th>
                <th className="head-insured">
                  {renderProvinceSortButton("insuredTotal", "جمع")}
                </th>
                <th className="head-pension">
                  {renderProvinceSortButton("pensionMen", "مرد")}
                </th>
                <th className="head-pension">
                  {renderProvinceSortButton("pensionWomen", "زن")}
                </th>
                <th className="head-pension">
                  {renderProvinceSortButton("pensionTotal", "جمع")}
                </th>
                <th className="head-coverage">
                  {renderProvinceSortButton("primaryMen", "مرد")}
                </th>
                <th className="head-coverage">
                  {renderProvinceSortButton("primaryWomen", "زن")}
                </th>
                <th className="head-coverage">
                  {renderProvinceSortButton("primaryTotal", "جمع")}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr className="national-total-row">
                <td><span className="code-chip">—</span></td>
                <td><strong>جمع</strong></td>
                <td>{numberFormat.format(summary.insuredMen)}</td>
                <td>{numberFormat.format(summary.insuredWomen)}</td>
                <td>{numberFormat.format(summary.insuredTotal)}</td>
                <td>{numberFormat.format(summary.insuredDependents)}</td>
                <td>{numberFormat.format(summary.pensionMen)}</td>
                <td>{numberFormat.format(summary.pensionWomen)}</td>
                <td>{numberFormat.format(summary.pensionTotal)}</td>
                <td>{numberFormat.format(summary.pensionDependents)}</td>
                <td>{numberFormat.format(summary.primaryMen)}</td>
                <td>{numberFormat.format(summary.primaryWomen)}</td>
                <td>{numberFormat.format(summary.primaryTotal)}</td>
                <td>{numberFormat.format(summary.dependents)}</td>
                <td className="total-cell">{numberFormat.format(summary.grandTotal)}</td>
              </tr>
              {pagedProvinceRows.map((row) => (
                <tr key={row.code}>
                  <td>
                    <span className="code-chip">{toFaDigits(row.code)}</span>
                  </td>
                  <td>
                    <strong>{row.name}</strong>
                  </td>
                  <td>{numberFormat.format(row.insuredMen)}</td>
                  <td>{numberFormat.format(row.insuredWomen)}</td>
                  <td>{numberFormat.format(row.insuredTotal)}</td>
                  <td>{numberFormat.format(row.insuredDependents)}</td>
                  <td>{numberFormat.format(row.pensionMen)}</td>
                  <td>{numberFormat.format(row.pensionWomen)}</td>
                  <td>{numberFormat.format(row.pensionTotal)}</td>
                  <td>{numberFormat.format(row.pensionDependents)}</td>
                  <td>{numberFormat.format(row.primaryMen)}</td>
                  <td>{numberFormat.format(row.primaryWomen)}</td>
                  <td>{numberFormat.format(row.primaryTotal)}</td>
                  <td>{numberFormat.format(row.dependents)}</td>
                  <td className="total-cell">{numberFormat.format(row.grandTotal)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!filteredRows.length && (
            <div className="empty-state">استانی با این عبارت پیدا نشد.</div>
          )}
        </div>
        <div className="pagination">
          <button
            type="button"
            disabled={provincePage === 1}
            onClick={() => setProvincePage((current) => current - 1)}
          >
            صفحه قبل
          </button>
          <span>
            صفحه {toFaDigits(provincePage)} از {toFaDigits(provincePageCount)}
            <small>{toFaDigits(filteredRows.length)} ردیف</small>
          </span>
          <button
            type="button"
            disabled={provincePage === provincePageCount}
            onClick={() => setProvincePage((current) => current + 1)}
          >
            صفحه بعد
          </button>
        </div>
          </>
        )}
      </section>

      {activeGeneratedReport && (
        <GeneratedReportPage
          key={`${activeGeneratedReport.definition.id}-${reportInitialQuery}`}
          report={activeGeneratedReport}
          sourceLabels={sourceLabels}
          period={activeReportPeriod}
          initialQuery={reportInitialQuery}
          onOpenSettings={() => navigateTo("settings")}
        />
      )}

      <section
        className={`inputs-section ${
          activePage === "home" ? "" : "page-hidden"
        }`}
        id="inputs"
      >
        <div className="section-heading">
          <div>
            <span className="section-kicker">نقشهٔ داده</span>
            <h2>دقیقاً چه ورودی‌هایی لازم است؟</h2>
          </div>
          <p>
            ۱۱ شیت مرجع در چهار گروه وارد می‌شوند و ۱۷ گزارش محاسبه‌شده را
            می‌سازند. هر شیت می‌تواند داخل فایل جامع یا فایل مستقل باشد.
          </p>
        </div>

        <div className="data-flow-map">
          <div className="data-flow-column">
            <span className="flow-stage">۱ — منابع پایه</span>
            <article className="data-flow-card flow-core">
              <strong>جمعیت و مراجع مکانی</strong>
              <div>
                <span>ماه جاری</span>
                <span>مستمری ماه جاری</span>
                <span>لیست استان</span>
                <span>لیست شعب</span>
              </div>
              <small>ساخت پوشش استانی و شعبه‌ای</small>
            </article>
          </div>

          <span className="flow-arrow" aria-hidden="true">←</span>

          <div className="data-flow-column">
            <span className="flow-stage">۲ — منابع تکمیلی</span>
            <article className="data-flow-card flow-comparison">
              <strong>مقایسه و کارگاه</strong>
              <div>
                <span>ماه گذشته</span>
                <span>کارگاه شعب ماه جاری</span>
                <span>کارگاه شعب ماه گذشته</span>
              </div>
              <small>تغییرات ماهانه و کارگاه فعال</small>
            </article>
            <article className="data-flow-card flow-treatment">
              <strong>نرخ و درمان</strong>
              <div>
                <span>حضوری</span>
                <span>غیرحضوری</span>
                <span>پورسانتاژ</span>
                <span>مجموع</span>
              </div>
              <small>تفکیک درمان، نرخ و بدون درمان</small>
            </article>
          </div>

          <span className="flow-arrow" aria-hidden="true">←</span>

          <div className="data-flow-column">
            <span className="flow-stage">۳ — موتور محاسبه</span>
            <article className="data-flow-card flow-engine">
              <strong>تطبیق بر اساس کد مشترک</strong>
              <p>
                کنترل نام شیت، تجمیع استان و شعبه، محاسبه اصلی و تبعی و کنترل
                جمع‌ها
              </p>
              <small>بدون استفاده از Cache یا لینک خارجی اکسل</small>
            </article>
          </div>

          <span className="flow-arrow" aria-hidden="true">←</span>

          <div className="data-flow-column">
            <span className="flow-stage">۴ — خروجی‌ها</span>
            <article className="data-flow-card flow-output">
              <strong>۱۷ صفحه گزارش</strong>
              <div>
                <span>پوشش استانی و شعبه‌ای</span>
                <span>پوشش درمان</span>
                <span>بیمه و مستمری</span>
                <span>کارگاه و گزارش مدیریتی</span>
              </div>
              <button type="button" onClick={() => setMenuOpen(true)}>
                مشاهده فهرست گزارش‌ها
              </button>
            </article>
          </div>
        </div>

        <div className="compatibility-note">
          <span aria-hidden="true">i</span>
          <div>
            <strong>ورودی جامع و ورودی چندفایلی هر دو پشتیبانی می‌شوند</strong>
            <p>
              فایل «داده های مرجع ورودی.xlsx» تمام منابع را یکجا فراهم می‌کند.
              همچنین می‌توانید هر شیت را در فایل مستقل اضافه کنید. فایل
              «جداول آماری.xlsx» نیز برای سازگاری قابل خواندن است، اما محاسبه از
              داده‌های خام دقیق‌تر و مستقل از لینک‌های خارجی است.
            </p>
          </div>
        </div>
      </section>

      {versionModalOpen && (
        <VersionHistoryModal
          versions={versions}
          selectedVersion={selectedVersion}
          onSelect={setSelectedVersion}
          onClose={() => setVersionModalOpen(false)}
        />
      )}

      <footer>
        <div className="brand footer-brand">
          <span className="brand-mark" aria-hidden="true">
            پ
          </span>
          <span>
            <strong>پوشش‌نما</strong>
            <small>از اکسل تا تصمیم</small>
          </span>
        </div>
        <div className="footer-copy">
          <p>تمام محاسبات در مرورگر شما انجام می‌شود؛ بدون آپلود فایل.</p>
          <a
            href="https://github.com/mnikoie2005-cmd/pooshesh-nama/raw/main/pooshesh-nama-source-v1.7.2.zip"
          >
            دریافت سورس کامل برنامه
          </a>
        </div>
      </footer>
    </main>
  );
}
