"use client";

import {
  DEFAULT_VERSION_HISTORY,
  VersionEntry,
  VersionType,
} from "./version-data";

function typeClass(type: VersionType) {
  if (type === "رفع ایراد") return "is-fix";
  if (type === "بهبود") return "is-improvement";
  if (type === "تغییر داده یا محاسبات") return "is-data";
  if (type === "نسخه اصلی") return "is-major";
  return "is-feature";
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("fa-IR", { dateStyle: "medium" }).format(
    new Date(`${value}T12:00:00`),
  );
}

function VersionCard({ version }: { version: VersionEntry }) {
  return (
    <article className="public-version-card">
      <div className="public-version-heading">
        <div>
          <span className={`version-type-chip ${typeClass(version.versionType)}`}>
            {version.versionType}
          </span>
          <h2>{version.title}</h2>
        </div>
        <strong dir="ltr">v{version.version}</strong>
      </div>
      <p>{version.summary}</p>
      <time dateTime={version.releasedAt}>{formatDate(version.releasedAt)}</time>
      <div className="public-version-changes">
        {version.changes.map((change, index) => (
          <div key={`${version.version}-${index}`}>
            <span className={`version-type-chip ${typeClass(change.changeType)}`}>
              {change.changeType}
            </span>
            <p>{change.description}</p>
          </div>
        ))}
      </div>
    </article>
  );
}

export default function PublicAdmin() {
  const latest = DEFAULT_VERSION_HISTORY[0];

  return (
    <main className="admin-shell public-admin-shell">
      <header className="admin-topbar public-admin-topbar">
        <div>
          <span className="section-kicker">نمای عمومی مدیریت</span>
          <h1>تاریخچه نسخه‌های پوشش‌نما</h1>
          <p>
            <strong>فقط‌خواندنی و بدون نیاز به ورود</strong>
            <span>ثبت و ویرایش نسخه‌ها فقط در پنل خصوصی مدیر انجام می‌شود.</span>
          </p>
        </div>
        <nav>
          <a className="secondary-button" href="./">
            بازگشت به برنامه
          </a>
          <a
            className="ghost-button"
            href="https://github.com/mnikoie2005-cmd/pooshesh-nama/raw/main/pooshesh-nama-source-v1.7.2.zip"
          >
            دریافت سورس
          </a>
          <a
            className="primary-button"
            href="https://pooshesh-nama.m-nikoie2005.chatgpt.site/admin"
          >
            ورود مدیر
          </a>
        </nav>
      </header>

      <section className="public-admin-summary">
        <article>
          <span>آخرین نسخه</span>
          <strong dir="ltr">v{latest.version}</strong>
          <small>{latest.title}</small>
        </article>
        <article>
          <span>نسخه‌های ثبت‌شده</span>
          <strong>{DEFAULT_VERSION_HISTORY.length}</strong>
          <small>از راه‌اندازی تا امروز</small>
        </article>
        <article>
          <span>وضعیت انتشار</span>
          <strong className="public-status-live">فعال</strong>
          <small>نسخه عمومی همگام با انتشار رسمی</small>
        </article>
      </section>

      <section className="public-version-grid">
        {DEFAULT_VERSION_HISTORY.map((version) => (
          <VersionCard version={version} key={version.version} />
        ))}
      </section>

      <div className="public-admin-footer">
        <p>
          این صفحه یک نمای عمومی از گزارش تغییرات است. پایگاه داده و ابزار
          ویرایش در پنل خصوصی مدیر محافظت می‌شوند.
        </p>
        <a href="https://github.com/mnikoie2005-cmd/pooshesh-nama">
          مشاهده مخزن عمومی
        </a>
      </div>
    </main>
  );
}
